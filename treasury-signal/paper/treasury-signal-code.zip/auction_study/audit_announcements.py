"""Sample original Treasury announcements, without reading auction results."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from io import BytesIO
import hashlib
import json
import re
import urllib.request
from pypdf import PdfReader

HERE = Path(__file__).resolve().parent


def category(row):
    term = str(row['original_security_term'])
    inflation = row['inflation_index_security']
    if term.startswith('20-Year') and inflation == 'No':
        return 'nominal_20'
    if term.startswith('30-Year'):
        return 'tips_30' if inflation == 'Yes' else 'nominal_30' if inflation == 'No' else None
    return None


def compact(text):
    return re.sub('[^a-z0-9]', '', text.lower())


def date_in(text, value):
    d = datetime.fromisoformat(value)
    return any(compact(s) in compact(text) for s in [d.strftime('%B ')+str(d.day)+d.strftime(', %Y'),
                                                    d.strftime('%b ')+str(d.day)+d.strftime(', %Y'),
                                                    d.strftime('%B %d, %Y'), d.strftime('%b %d, %Y')])


def fetch(row):
    year = row['announcemt_date'][:4]
    url = f"https://www.treasurydirect.gov/instit/annceresult/press/preanre/{year}/{row['pdf_filenm_announcemt']}"
    out = {**row, 'category': category(row), 'url': url}
    try:
        cache = HERE/'announcement_samples'/year/row['pdf_filenm_announcemt']
        if cache.exists():
            raw = cache.read_bytes()
        else:
            req = urllib.request.Request(url, headers={'User-Agent': 'TreasuryChecklistResearch/1.0'})
            with urllib.request.urlopen(req, timeout=40) as response:
                raw = response.read()
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_bytes(raw)
        text = '\n'.join(p.extract_text() or '' for p in PdfReader(BytesIO(raw)).pages)
        out.update(sha256=hashlib.sha256(raw).hexdigest(),
                   announcement_date_found=date_in(text, row['announcemt_date']),
                   auction_date_found=date_in(text, row['auction_date']),
                   cusip_found=compact(row['cusip']) in compact(text))
        out['passed'] = all(out[k] for k in ['announcement_date_found', 'auction_date_found', 'cusip_found'])
        cache.with_suffix('.txt').write_text(text, encoding='utf-8')
    except Exception as exc:
        out.update(passed=False, error=str(exc))
    return out


def main():
    rows = json.loads((HERE/'auction_calendar_records.json').read_text())
    # Outcome-independent sample: first/last auction in each fixed calendar block.
    sample = {}
    for name in ['nominal_20', 'nominal_30', 'tips_30']:
        for lo, hi in [(2001, 2005), (2006, 2010), (2011, 2016), (2017, 2020), (2021, 2026)]:
            block = [r for r in rows if category(r) == name and lo <= int(r['auction_date'][:4]) <= hi]
            if block:
                for r in [block[0], block[-1]]:
                    sample[(r['cusip'], r['auction_date'])] = r
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(fetch, sample.values()))
    out = {'scope': 'Outcome-independent sample, not verification of every historical announcement or all calendar revisions.',
           'sample_rule': 'First and last per type within 2001-05, 2006-10, 2011-16, 2017-20 and 2021-26.',
           'sampled': len(results), 'passed': sum(r['passed'] for r in results), 'records': results}
    (HERE/'announcement_audit.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
    print({k: v for k, v in out.items() if k != 'records'})
    for r in results:
        if not r['passed']:
            print(r)


if __name__ == '__main__':
    main()
