"""Download only identifying/calendar fields from the official Treasury API."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib
import json
import urllib.parse
import urllib.request

HERE=Path(__file__).resolve().parent
BASE='https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/od/auctions_query'
FIELDS=['cusip','security_type','security_term','original_security_term',
        'inflation_index_security','announcemt_date','auction_date','issue_date',
        'maturity_date','reopening','pdf_filenm_announcemt']


def main():
    rows=[];sources=[];page=1
    while True:
        query={'fields':','.join(FIELDS),
               'filter':'auction_date:gte:1999-01-01,auction_date:lte:2026-10-30',
               'sort':'auction_date,cusip','page[size]':'10000','page[number]':str(page)}
        url=BASE+'?'+urllib.parse.urlencode(query)
        req=urllib.request.Request(url,headers={'User-Agent':'TreasuryChecklistResearch/1.0'})
        with urllib.request.urlopen(req,timeout=60) as response:result=json.load(response)
        rows.extend(result['data']);sources.append(url)
        if page>=result['meta']['total-pages']:break
        page+=1
    expected=int(result['meta']['total-count'])
    assert len(rows)==expected,(len(rows),expected)
    data=HERE/'auction_calendar_records.json'
    data.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    (HERE/'source_manifest.json').write_text(json.dumps({
        'downloaded_at_utc':datetime.now(timezone.utc).isoformat(),
        'urls':sources,'fields':FIELDS,'records':len(rows),
        'sha256':hashlib.sha256(data.read_bytes()).hexdigest(),
        'scope':'Current retrieval of dated Treasury calendar/identity records; no auction-result fields downloaded.'},indent=2)+'\n',encoding='utf-8')
    from collections import Counter
    print('Total records',len(rows))
    long=[r for r in rows if any(x in r['original_security_term'] for x in ['20-Year','30-Year'])]
    print('Long records',len(long),'types',Counter((r['security_type'],r['original_security_term'],r['inflation_index_security']) for r in long))
    for r in long[:3]+long[-3:]:print(r)


if __name__=='__main__':main()
