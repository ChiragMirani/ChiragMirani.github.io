"""Checks prevent future announcements and incorrect bond types entering flags."""
import unittest
import pandas as pd
from auction_study.analyze import make_flags
from auction_study.audit_announcements import category


def row(announce='2026-01-08', auction='2026-01-15', term='30-Year', inflation='No', cusip='test'):
    return {'cusip': cusip, 'original_security_term': term, 'security_term': '29-Year 10-Month',
            'inflation_index_security': inflation, 'announcemt_date': announce, 'auction_date': auction}


class TimingTests(unittest.TestCase):
    def setUp(self):
        self.fridays = pd.DatetimeIndex(['2026-01-02', '2026-01-09', '2026-01-16'])

    def test_gate_excludes_same_friday_and_future_announcement(self):
        for date in ['2026-01-09', '2026-01-12']:
            flags, _ = make_flags(self.fridays, [row(announce=date)])
            self.assertEqual(flags.to_numpy().sum(), 0)
        flags, _ = make_flags(self.fridays, [row()])
        self.assertEqual(list(flags.nominal_30), [0, 1, 0])

    def test_next_friday_included_current_friday_excluded(self):
        flags, _ = make_flags(self.fridays, [row(auction='2026-01-16')])
        self.assertEqual(list(flags.nominal_30), [0, 1, 0])

    def test_original_tenor_and_inflation_identity(self):
        self.assertEqual(category(row()), 'nominal_30')
        self.assertEqual(category(row(term='30-Year 6-Month', inflation='Yes')), 'tips_30')
        self.assertIsNone(category(row(term='20-Year', inflation='Yes')))
        self.assertEqual(category(row(term='20-Year')), 'nominal_20')

    def test_union_one_vote_and_future_invariance(self):
        rows = [row(), row(term='20-Year', cusip='other')]
        flags, _ = make_flags(self.fridays, rows)
        self.assertEqual(list(flags.any_long), [0, 1, 0])
        future = row(announce='2026-02-05', auction='2026-02-12', cusip='future')
        extra, _ = make_flags(self.fridays, rows+[future])
        pd.testing.assert_frame_equal(flags, extra)

    def test_bad_dates_and_duplicate_records_rejected(self):
        with self.assertRaises(ValueError):
            make_flags(self.fridays, [row(announce='2026-01-17')])
        with self.assertRaises(ValueError):
            make_flags(self.fridays, [row(), row()])


if __name__ == '__main__':
    unittest.main()
