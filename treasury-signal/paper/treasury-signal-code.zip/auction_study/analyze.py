"""Eight disclosed auction extensions. Never modifies the frozen live model."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys
import argparse
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import model as M
from improvement_study.search import metrics, score_arrays, nw_t, write_json
from auction_study.audit_announcements import category

NAMES = ['nominal_20', 'nominal_30', 'tips_30', 'any_long']


def make_flags(index, rows):
    flags = pd.DataFrame(0, index=index, columns=NAMES, dtype=int)
    audit = []
    seen = set()
    for row in rows:
        name = category(row)
        if name is None:
            continue
        key = (row['cusip'], row['auction_date'])
        if key in seen:
            raise ValueError(f'Duplicate auction: {key}')
        seen.add(key)
        announce = pd.Timestamp(row['announcemt_date'])
        auction = pd.Timestamp(row['auction_date'])
        if pd.isna(announce) or pd.isna(auction) or announce > auction:
            raise ValueError(f'Invalid dates: {row}')
        event = (index < auction) & (auction <= index + pd.Timedelta(days=7)) & (announce < index)
        flags.loc[event, name] = 1
        for friday in index[event]:
            audit.append({'signal_date': str(friday.date()), 'category': name, **row})
    flags['any_long'] = flags[NAMES[:3]].max(axis=1)
    return flags, audit


def extended_metrics(pos, y):
    out = metrics(pos, y)
    p, gross, net, _ = score_arrays(pos, y)
    active = np.abs(p) > 1e-12
    n = int(active.sum()); wins = int((gross[active] > 0).sum())
    z = 1.959963984540054
    if n:
        h = wins/n; center = (h+z*z/(2*n))/(1+z*z/n)
        radius = z*np.sqrt(h*(1-h)/n+z*z/(4*n*n))/(1+z*z/n)
        interval = [center-radius, center+radius]
    else:
        interval = [None, None]
    return {**out, 'gross_t_8': nw_t(gross, 8), 'net_t_8': nw_t(net, 8),
            'gross_total_bp': float(gross.sum()), 'wins': wins, 'hit_rate_95': interval}


def paired(pos, base, y):
    _, g, n, _ = score_arrays(pos, y)
    _, bg, bn, _ = score_arrays(base, y)
    return {'gross_bp_year': float((g-bg).mean()*52), 'gross_t': nw_t(g-bg),
            'net_bp_year': float((n-bn).mean()*52), 'net_t': nw_t(n-bn)}


def positions(score, probability):
    return np.sign(np.sign(score)+np.sign(probability-.5)).fillna(0)


def main(refit_weeks=52):
    output = HERE if refit_weeks == 52 else HERE/'quarterly'
    output.mkdir(exist_ok=True)
    rows = json.loads((HERE/'auction_calendar_records.json').read_text())
    d = M.load(); dy = d.dy_next_bp
    a, f = M.answers_13(d), M.features_13(d)
    flags, events = make_flags(d.index, rows)
    flags.to_csv(output/'weekly_flags.csv', index_label='signal_date')
    pd.DataFrame(events).to_csv(output/'eligible_events.csv', index=False)
    early = (d.index >= M.CLF_START) & (d.index+pd.Timedelta(days=7) < pd.Timestamp('2016-11-01')) & dy.notna()
    later = (d.index >= M.HOLDOUT_START) & dy.notna()
    cut = d.index[early][-1]
    assert str(cut.date()) == '2016-10-21'
    # Rank truncated fits. Later outcomes cannot enter the selection computations.
    early_rows = []
    for name in NAMES:
        ff = f.assign(**{name: flags[name]})
        p, _ = M.walk_forward(ff.loc[:cut], dy.loc[:cut], refit_weeks=refit_weeks)
        for sign in [-1, 1]:
            pos = positions(a.sum(axis=1).loc[:cut]+sign*flags.loc[:cut, name], p)
            mask = early[:len(pos)]
            e = extended_metrics(pos[mask], dy.loc[pos.index][mask])
            count = int(flags.loc[early, name].sum())
            early_rows.append({'candidate': name, 'sign': sign, 'early_events': count,
                               'eligible': count >= 20, **e})
    early_table = pd.DataFrame(early_rows)
    early_table.to_csv(output/'all_early_trials.csv', index=False)
    ranked = early_table[early_table.eligible].sort_values(['gross_t', 'candidate', 'sign'], ascending=[False, True, True])
    selection = {'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
                 'protocol_sha256': hashlib.sha256((output/'PROTOCOL.txt').read_bytes()).hexdigest(),
                 'original_protocol_sha256': hashlib.sha256((HERE/'PROTOCOL.txt').read_bytes()).hexdigest(),
                 'refit_weeks': refit_weeks,
                 'data_sha256': hashlib.sha256((HERE/'auction_calendar_records.json').read_bytes()).hexdigest(),
                 'model_sha256': hashlib.sha256((HERE.parent/'model.py').read_bytes()).hexdigest(),
                 'ranking': 'Highest early gross calendar-week t; at least 20 early event weeks.',
                 'trials': 8, 'last_early_signal': str(cut.date()),
                 'winner': ranked.iloc[0].to_dict(),
                 'per_flag': ranked.groupby('candidate', sort=False).first().reset_index().to_dict('records')}
    write_json(output/'selection_before_later_evaluation.json', selection)
    print('Early selection saved:', selection['winner']['candidate'], selection['winner']['sign'], flush=True)
    # Evaluate only after the early selection file exists.
    main = M.two_key(a, f, dy, refit_weeks=refit_weeks)['two_key']
    reference_path = 'results/two_key_weekly.csv' if refit_weeks == 52 else 'improvement_study/refit_weekly.csv'
    reference = pd.read_csv(HERE.parent/reference_path, index_col=0, parse_dates=True)
    reference_column = 'two_key_position' if refit_weeks == 52 else 'position_13'
    shared = main.index.intersection(reference.index)
    shared = shared[shared >= M.CLF_START]
    assert np.array_equal(main.loc[shared].values, reference.loc[shared, reference_column].values)
    assert np.allclose(dy.loc[shared], reference.loc[shared, 'dy_next_bp'], equal_nan=True)
    assert round(metrics(main[later], dy[later])['gross_bp_year'], 1) == M.evaluate(main, dy.where(later))['bp_per_year']
    first20 = flags.index[flags.nominal_20.eq(1)][0]
    periods = {'early': early, 'later': later, 'since_20_reintroduction': later & (d.index >= first20),
               '2026': later & (d.index.year == 2026), 'last_52': d.index.isin(d.index[later][-52:])}
    conditional, standalone, combined, flat_rows = {}, {}, {}, []
    weekly = pd.DataFrame({'dy_next_bp': dy, 'baseline': main}, index=d.index).join(flags.add_prefix('flag_'))
    for name in NAMES:
        conditional[name] = {}; standalone[name] = {}; combined[name] = {}
        p, _ = M.walk_forward(f.assign(**{name: flags[name]}), dy, refit_weeks=refit_weeks)
        for label, mask in periods.items():
            event = mask & flags[name].eq(1)
            no_event = mask & flags[name].eq(0)
            conditional[name][label] = {'weeks': int(mask.sum()), 'event_weeks': int(event.sum()),
                    'non_event_weeks': int(no_event.sum()), 'event_mean_yield_change_bp': float(dy[event].mean()),
                    'non_event_mean_yield_change_bp': float(dy[no_event].mean())}
        for sign in [-1, 1]:
            pos = positions(a.sum(axis=1)+sign*flags[name], p)
            weekly[f'{name}_{sign:+d}'] = pos
            per = {}; alone = {}
            for label, mask in periods.items():
                per[label] = {**extended_metrics(pos[mask], dy[mask]), 'paired': paired(pos[mask], main[mask], dy[mask]),
                              'paired_always_reduce': paired(pos[mask], pd.Series(-1., index=d.index)[mask], dy[mask])}
                alone[label] = extended_metrics(sign*flags.loc[mask, name], dy[mask])
                flat_rows.append({'kind': 'combined', 'candidate': name, 'sign': sign, 'period': label,
                                  **{k: v for k, v in per[label].items() if k not in ['paired', 'paired_always_reduce', 'hit_rate_95']},
                                  **{'paired_'+k: v for k, v in per[label]['paired'].items()}})
                flat_rows.append({'kind': 'event_only', 'candidate': name, 'sign': sign, 'period': label,
                                  **{k: v for k, v in alone[label].items() if k != 'hit_rate_95'}})
            combined[name][str(sign)] = per
            standalone[name][str(sign)] = alone
            e = early_table[(early_table.candidate == name) & (early_table.sign == sign)].iloc[0]
            assert np.isclose(e.gross_bp_year, per['early']['gross_bp_year'])
            print(name, sign, 'later', round(per['later']['gross_bp_year'], 2), 'paired', round(per['later']['paired']['gross_t'], 2), flush=True)
    pd.DataFrame(flat_rows).to_csv(output/'all_results.csv', index=False)
    weekly.to_csv(output/'all_weekly_positions.csv', index_label='signal_date')
    audit = json.loads((HERE/'announcement_audit.json').read_text())
    out = {'selection': selection, 'refit_weeks': refit_weeks, 'calendar_records': len(rows), 'first_nominal_20_signal': str(first20.date()),
           'periods': {k: {'first_signal': str(d.index[m][0].date()), 'last_signal': str(d.index[m][-1].date()),
                           'last_outcome': str((d.index[m][-1]+pd.Timedelta(days=7)).date()), 'weeks': int(m.sum())} for k, m in periods.items()},
           'baseline': {k: extended_metrics(main[m], dy[m]) for k, m in periods.items()},
           'always_reduce': {k: extended_metrics(pd.Series(-1., index=d.index)[m], dy[m]) for k, m in periods.items()},
           'conditional': conditional, 'standalone': standalone, 'combined': combined,
           'announcement_audit': {k: v for k, v in audit.items() if k != 'records'},
           'scope': 'Retrospective exploratory search; historical calendar dates from current official records; sampled original notices only; no change to production model.'}
    write_json(output/'summary.json', out)
    assert np.isclose(nw_t(score_arrays(main[later], dy[later])[1]), M.hac_t(M.weekly_score(main[later], dy[later])))
    print('Saved all eight trials, both standalone signs, calendar flags and paired comparisons.', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--refit-weeks', type=int, choices=[52, 13], default=52)
    args = parser.parse_args()
    with threadpool_limits(1):
        main(args.refit_weeks)
