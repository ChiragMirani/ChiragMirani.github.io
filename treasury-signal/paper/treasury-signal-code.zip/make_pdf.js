const {chromium} = require('playwright');
const path = require('path');
const fs = require('fs');
const os = require('os');
const {spawnSync} = require('child_process');
const {pathToFileURL} = require('url');
(async () => {
  const browser = await chromium.launch(process.env.PAPER_CHROMIUM ? {executablePath: process.env.PAPER_CHROMIUM} : {});
  const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'treasury-paper-'));
  const cover = path.join(temporary, 'cover.pdf');
  const body = path.join(temporary, 'body.pdf');
  try {
    const page = await browser.newPage();
    await page.goto(pathToFileURL(path.join(__dirname, 'paper.html')).href);
    await page.evaluate(() => document.fonts.ready);
    const options = {format:'Letter', preferCSSPageSize:true, printBackground:true,
      displayHeaderFooter:true,
      footerTemplate:'<div style="font-family:Times New Roman,serif;font-size:9pt;width:100%;text-align:center;color:#777"><span class="pageNumber"></span></div>'};
    await page.pdf({...options, path:cover, pageRanges:'1', headerTemplate:'<span></span>'});
    await page.pdf({...options, path:body, pageRanges:'2-',
      headerTemplate:'<div style="font-family:Times New Roman,serif;font-size:8.5pt;color:#666;width:100%;margin:30px 1.2in 0;border-bottom:0.5pt solid #bbb;padding-bottom:4px;display:flex;justify-content:space-between"><span>A Simple Weekly Treasury Signal</span><b>Mirani (2026)</b></div>'});
    const merged = spawnSync(process.env.PAPER_PYTHON || 'python',
      [path.join(__dirname,'merge_paper_pdf.py'),cover,body,
       path.join(__dirname,'A_Simple_Weekly_Signal_US_10Y_Treasury_Yield.pdf')],{encoding:'utf8'});
    if (merged.status !== 0) throw new Error(merged.stderr || merged.error || 'PDF merge failed');
  } finally {
    await browser.close();
    for (const file of [cover,body]) if (fs.existsSync(file)) fs.unlinkSync(file);
    fs.rmdirSync(temporary);
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
