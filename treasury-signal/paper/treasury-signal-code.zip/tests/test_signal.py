"""Regression checks for timing, fixed positions, statistics and fail-closed publication.
Run from the release folder: python -m unittest discover -s tests -v
Historical checks run only when the archived local research data are present.
"""
import contextlib
import io
import json
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import model as M
import production_signal as P
import download_data as D


class SignalTests(unittest.TestCase):
    def test_unchanged_quoted_curve_has_no_roundoff_vote(self):
        idx = pd.date_range('2026-01-02', periods=5, freq='W-FRI')
        cols = ['y10','y2','us_eq','em_eq','oil','usd','vix','unrate','unrate_5y',
                'core_pce_yoy','real_y10','de10_chg','jp10_chg','uk10_chg']
        d = pd.DataFrame(1., index=idx, columns=cols)
        d['y10'], d['y2'] = .3, .2
        d.loc[idx[-1], ['y10','y2']] = [.4,.3]
        self.assertNotEqual((d.y10-d.y2).diff(4).iloc[-1], 0)
        self.assertEqual(M.curve_change(d).iloc[-1], 0)
        self.assertEqual(M.answers_13(d).curve.iloc[-1], 0)
        d.loc[idx[-1], 'y10'] = .41
        self.assertAlmostEqual(M.curve_change(d).iloc[-1], .01)
        self.assertEqual(M.answers_13(d).curve.iloc[-1], 1)

    def test_position_is_fixed_and_neutral_defers_to_classifier(self):
        idx = pd.date_range('2026-01-02', periods=5, freq='W-FRI')
        answers = pd.DataFrame({'one': [9, 1, -9, 0, -1]}, index=idx)
        probabilities = pd.Series([.99, .51, .01, .7, .7], index=idx)
        with patch.object(M, 'walk_forward', return_value=(probabilities, pd.DataFrame())):
            out = M.two_key(answers, answers, probabilities)
        self.assertEqual(out['two_key'].tolist(), [1, 1, -1, 1, 0])

    def test_hac_and_calendar_weeks(self):
        x = pd.Series([3., 0., -1., 2., 0., 4., -2., 0., 1., 3.])
        e = x - x.mean()
        n, lag = len(x), 4
        meat = float(e @ e) + sum(2 * (1-k/(lag+1)) * float(e.iloc[k:].values @ e.iloc[:-k].values) for k in range(1, lag+1))
        self.assertAlmostEqual(M.hac_t(x), x.mean() / np.sqrt(meat / n**2), places=10)
        out = M.evaluate(x.ne(0).astype(int), -x)
        self.assertEqual(out['calendar_weeks'], 10)
        self.assertEqual(out['active_weeks'], 7)
        self.assertEqual(out['bp_per_year'], round(x.mean()*52, 1))

    def test_archive_rejects_old_and_duplicate_observation_months(self):
        frame = pd.DataFrame({'vintage': pd.to_datetime(['2013-07-01']*2+['2013-08-01']*2+['2013-09-01']*2),
                              'obs': pd.to_datetime(['2013-05-01','2013-06-01','1969-11-01','1969-12-01','2013-08-01','2013-08-01']),
                              'value': [1.,2.,1.,2.,1.,2.]})
        with patch.object(M, 'vintages', return_value=frame):
            self.assertEqual([str(d.date()) for d, _ in M.valid_releases('x')], ['2013-07-01'])

    def test_revision_only_release_is_not_an_extra_month(self):
        groups = [(pd.Timestamp(d), pd.DataFrame({'obs': pd.to_datetime([o]), 'value':[v]}))
                  for d,o,v in [('2026-02-06','2026-01-01',4.0),('2026-02-13','2026-01-01',4.1),('2026-03-06','2026-02-01',4.2)]]
        with patch.object(M, 'valid_releases', return_value=iter(groups)):
            self.assertEqual(M.unemployment_first_prints().tolist(), [4.0,4.2])

    def test_wall_clock_friday_does_not_follow_stale_file(self):
        self.assertEqual(P.expected_friday(datetime(2026,11,14,12,tzinfo=timezone.utc)), pd.Timestamp('2026-11-13'))

    def test_one_stale_currency_withholds(self):
        t = pd.Timestamp('2026-11-13')
        d = pd.DataFrame(1., index=[t], columns=list(P.MARKET)+['usd','unrate','unrate_5y','core_pce_yoy','real_y10','de10_chg','jp10_chg','uk10_chg'])
        def fred(code):
            lag = 7 if code.startswith('DEX') or code == 'DCOILWTICO' else 0
            age = 1 if code == 'DEXJPUS' else 0
            return pd.Series([1.], index=[t-pd.Timedelta(days=lag+age)])
        group = pd.DataFrame({'obs':[pd.Timestamp('2026-10-01')], 'value':[1.]})
        with patch.object(M,'fred',side_effect=fred), patch.object(M,'valid_releases',return_value=[(t,group)]), patch.object(M,'unemployment_first_prints',return_value=pd.Series([1.],index=[t])):
            with self.assertRaisesRegex(ValueError,'DEXJPUS'):
                P.check_inputs(t,d)

    def test_changed_source_is_rejected(self):
        spec = json.loads(P.SPEC_PATH.read_text())
        P.validate_spec(spec)
        spec['source_sha256']['model.py'] = 'wrong'
        with self.assertRaisesRegex(ValueError,'Source changed'):
            P.validate_spec(spec)

    def test_snapshot_corruption_is_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            root=Path(folder); snap=root/'data/snapshots/example'; snap.mkdir(parents=True)
            (root/'data/latest_snapshot.json').write_text('{"snapshot":"snapshots/example"}')
            (snap/'DGS10.csv').write_text('changed')
            (snap/'manifest.json').write_text(json.dumps({'completed_at_utc':'2026-11-13T23:00:00+00:00','sha256':{'DGS10.csv':'incorrect'}}))
            with patch.object(M,'ROOT',root), self.assertRaisesRegex(ValueError,'checksum'):
                P.use_snapshot(datetime(2026,11,13,23,30,tzinfo=timezone.utc))

    def test_prelaunch_never_creates_a_historical_forecast(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder, contextlib.ExitStack() as stack:
            root=Path(folder)
            stack.enter_context(patch.object(P,'RECORDS',root/'issued'))
            stack.enter_context(patch.object(P,'LATEST',root/'latest.json'))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            out=P.main(datetime(2026,11,7,15,tzinfo=timezone.utc))
            self.assertEqual(out['status'],'withheld'); self.assertIsNone(out['position'])
            self.assertFalse(P.RECORDS.exists())

    def test_failed_download_preserves_good_pointer(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            root = Path(folder)
            pointer = root/'latest_snapshot.json'
            previous = root/'snapshots/previous'
            previous.mkdir(parents=True)
            pointer.write_text('{"snapshot":"snapshots/previous"}')
            before = pointer.read_bytes()
            with patch.object(D,'DATA',root), patch.object(D,'fetch',side_effect=RuntimeError('offline')):
                with self.assertRaisesRegex(RuntimeError,'offline'):
                    D.download_snapshot()
            self.assertEqual(pointer.read_bytes(),before)

    def test_strict_json_nulls(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder:
            path=Path(folder)/'record.json'
            P.write_json(path, {'missing':float('nan'),'bad':float('inf')}, exclusive=True)
            self.assertEqual(json.loads(path.read_text()),{'missing':None,'bad':None})
            with self.assertRaises(FileExistsError):
                P.write_json(path, {}, exclusive=True)

    def test_issue_once_and_reuse_without_recomputing(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder, contextlib.ExitStack() as stack:
            root=Path(folder); snap=root/'snapshot';snap.mkdir();(snap/'manifest.json').write_text('{}')
            for name in ['RECORDS','MODELS','OUTCOMES']:
                stack.enter_context(patch.object(P,name,root/name))
            stack.enter_context(patch.object(P,'LATEST',root/'latest.json'))
            stack.enter_context(patch.object(P,'use_snapshot',return_value=snap))
            stack.enter_context(patch.object(P,'check_inputs',return_value={}))
            stack.enter_context(patch.object(P.A,'read_calendar',return_value={'records':[], 'source':'test', 'fetched_at_utc':'2026-11-13T23:00:00Z', 'latest_announcement':'2026-11-12'}))
            stack.enter_context(patch.object(P,'live_history',return_value=[]))
            t=pd.Timestamp('2026-11-13'); d=pd.DataFrame({'y10':[4.5],'dy_next_bp':[np.nan]},index=[t])
            stack.enter_context(patch.object(M,'load',return_value=d))
            stack.enter_context(patch.object(M,'answers_13',return_value=pd.DataFrame({'x':[1]},index=[t])))
            stack.enter_context(patch.object(M,'features_13',return_value=pd.DataFrame({'x':[1.]},index=[t])))
            fit=stack.enter_context(patch.object(P,'fitted_model',return_value=(.6,{})))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            first=P.main(datetime(2026,11,13,23,30,tzinfo=timezone.utc))
            raw=(P.RECORDS/'2026-11-13.json').read_bytes()
            second=P.main(datetime(2026,11,16,15,tzinfo=timezone.utc))
            self.assertEqual(first,second)
            self.assertEqual(first['position'],1)
            self.assertEqual(fit.call_count,1)
            self.assertEqual((P.RECORDS/'2026-11-13.json').read_bytes(),raw)

    def test_missing_snapshot_is_unavailable_not_flat(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder, contextlib.ExitStack() as stack:
            root=Path(folder)
            stack.enter_context(patch.object(P,'RECORDS',root/'issued'))
            stack.enter_context(patch.object(P,'LATEST',root/'latest.json'))
            stack.enter_context(patch.object(P,'use_snapshot',side_effect=ValueError('stale snapshot')))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            out=P.main(datetime(2026,11,13,23,30,tzinfo=timezone.utc))
            self.assertEqual(out['status'],'withheld'); self.assertIsNone(out['position'])
            self.assertFalse(P.RECORDS.exists())


@unittest.skipUnless((M.DATA/'DGS10.csv').exists(), 'Requires the archived research inputs')
class HistoricalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d=M.load();cls.f=M.features_13(cls.d);cls.a=M.answers_13(cls.d)
        cls.tk=M.two_key(cls.a,cls.f,cls.d.dy_next_bp)
        cls.quarterly=M.two_key(cls.a,cls.f,cls.d.dy_next_bp,refit_weeks=13)

    def test_main_statistics_reconcile(self):
        expected=json.loads((M.OUT/'summary.json').read_text())
        for mask,key in [('design','two_key_design'),('test','two_key_test'),('last_year','two_key_last_year')]:
            self.assertEqual(json.loads(json.dumps(M.evaluate(self.tk['two_key'],self.d.dy_next_bp.where(M.periods(self.d)[mask])))),expected[key])

    def test_production_refit_matches_research_and_retains_weights(self):
        t=self.d.index[-1];spec=json.loads(P.SPEC_PATH.read_text())
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder, patch.object(P,'MODELS',Path(folder)):
            probability, artifact=P.fitted_model(self.f,self.d.dy_next_bp,t,spec,M.DATA)
            self.assertEqual(spec['clf_refit_weeks'],13)
            self.assertAlmostEqual(probability,self.quarterly['prob'].loc[t],places=12)
            changed=self.d.dy_next_bp.copy();changed[:]=changed*-1
            again, cached=P.fitted_model(self.f,changed,t,spec,M.DATA)
            self.assertEqual(probability,again);self.assertEqual(artifact,cached)

    def test_future_rows_do_not_change_current_features_or_prediction(self):
        t=pd.Timestamp('2020-01-03'); early=M.load(end=str(t.date()))
        f=M.features_13(early)
        np.testing.assert_allclose(f.loc[t],self.f.loc[t])
        prob,_=M.walk_forward(f,early.dy_next_bp)
        self.assertAlmostEqual(prob.loc[t],self.tk['prob'].loc[t],places=12)
        quarterly,_=M.walk_forward(f,early.dy_next_bp,refit_weeks=13)
        self.assertAlmostEqual(quarterly.loc[t],self.quarterly['prob'].loc[t],places=12)

    def test_quarterly_refits_on_the_frozen_anchor_and_holds_between(self):
        spec=json.loads(P.SPEC_PATH.read_text()); first=self.f.index.get_loc(pd.Timestamp(spec['clf_start']))
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as folder, patch.object(P,'MODELS',Path(folder)):
            for offset in [12,13,14,25,26]:
                t=self.f.index[first+offset]
                probability, artifact=P.fitted_model(self.f,self.d.dy_next_bp,t,spec,M.DATA)
                expected=self.f.index[first+(offset//13)*13]
                self.assertEqual(artifact['refit'],str(expected.date()))
                self.assertAlmostEqual(probability,self.quarterly['prob'].loc[t],places=12)

    def test_quarterly_reproduces_the_existing_sensitivity_row(self):
        expected=json.loads((M.OUT/'summary.json').read_text())['robust_refit_13w_test']
        actual=M.evaluate(self.quarterly['two_key'],self.d.dy_next_bp.where(M.periods(self.d)['test']))
        self.assertEqual(json.loads(json.dumps(actual)),expected)


if __name__=='__main__':
    unittest.main()
