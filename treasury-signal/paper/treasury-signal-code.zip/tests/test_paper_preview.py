"""The cover must not present an older or unissued preview as a current live call."""
import contextlib
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import model as M
import production_signal as P
import paper_signal_preview as R


class PreviewTests(unittest.TestCase):
    def run_preview(self, missing_current):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as temporary:
            root=Path(temporary)
            spec_path=root/'spec.json'
            spec_path.write_text(json.dumps({'live_start':'2026-11-13','version':'test-version','clf_refit_weeks':13}))
            (root/'manifest.json').write_text(json.dumps({'completed_at_utc':'2026-11-07T17:00:00+00:00'}))
            dates=pd.to_datetime(['2026-10-30','2026-11-06'])
            d=pd.DataFrame({'dy_next_bp':[np.nan,np.nan]},index=dates)
            a=pd.DataFrame([[1]*5+[-1]*7+[0]]*2,index=dates,columns=[q[0] for q in M.QUESTIONS_13])
            probability=pd.Series([.5430754073,.52],index=dates)
            def validate_date(t, _):
                if missing_current and t==dates[-1]:raise ValueError('y10 is missing or stale')
                return {}
            with contextlib.ExitStack() as stack:
                for target,name,value in [(P,'SPEC_PATH',spec_path),(M,'OUT',root/'results')]:
                    stack.enter_context(patch.object(target,name,value))
                stack.enter_context(patch.object(P,'validate_spec'))
                stack.enter_context(patch.object(P,'use_snapshot',return_value=root))
                stack.enter_context(patch.object(P,'check_inputs',side_effect=validate_date))
                stack.enter_context(patch.object(M,'load',return_value=d))
                stack.enter_context(patch.object(M,'answers_13',return_value=a))
                stack.enter_context(patch.object(M,'features_13',return_value=a.astype(float)))
                stack.enter_context(patch.object(R.A,'read_calendar',return_value={'records':[]}))
                fit=stack.enter_context(patch.object(M,'two_key',return_value={'prob':probability}))
                stack.enter_context(patch.object(P,'main',side_effect=AssertionError('Must not issue')))
                stack.enter_context(patch.object(P,'fitted_model',side_effect=AssertionError('Must not persist a production fit')))
                stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
                out=R.preview(datetime(2026,11,7,17,8,10,tzinfo=timezone.utc))
            fit.assert_called_once()
            self.assertEqual(fit.call_args.kwargs['refit_weeks'],13)
            self.assertFalse((root/'results/issued').exists())
            self.assertFalse(out['live_record_created'])
            saved=json.loads((root/'results/paper_signal_preview.json').read_text())
            self.assertEqual(saved,out)
            return out

    def test_stale_current_week_stays_unavailable_with_separate_older_example(self):
        out=self.run_preview(True)
        self.assertEqual(out['status'],'unavailable')
        self.assertIsNone(out['position'])
        self.assertEqual(out['requested_reference_friday'],'2026-11-06')
        self.assertEqual(out['latest_complete_research_reading']['reference_friday'],'2026-10-30')
        self.assertEqual(out['latest_complete_research_reading']['target_end'],'2026-11-06')
        self.assertEqual(out['checked_at_new_york'],'2026-11-07T12:08:10-05:00')

    def test_complete_current_week_is_still_only_a_research_preview(self):
        out=self.run_preview(False)
        self.assertEqual(out['status'],'research_preview_only')
        self.assertEqual(out['position'],0)
        self.assertEqual(out['latest_complete_research_reading']['reference_friday'],'2026-11-06')
        self.assertEqual(out['live_start'],'2026-11-13')


if __name__=='__main__':unittest.main()
