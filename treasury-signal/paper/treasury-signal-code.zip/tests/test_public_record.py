import json
from datetime import datetime,timezone
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import build_public_page as B
import production_signal as P


class PublicRecordTests(unittest.TestCase):
    def test_pending_flat_and_missing_are_not_successful_calls(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            root=Path(folder);records=root/'issued';outcomes=root/'outcomes';records.mkdir();outcomes.mkdir()
            for date,pos,score in [('2026-11-13',1,4),('2026-11-20',0,0),('2026-11-27',-1,None)]:
                (records/(date+'.json')).write_text(json.dumps({'signal_date':date,'position':pos,'snapshot':'PRIVATE_LOCAL_PATH','features':{'private':99}}))
                if score is not None:(outcomes/(date+'.json')).write_text(json.dumps({'score_bp':score}))
            with patch.object(P,'RECORDS',records),patch.object(P,'OUTCOMES',outcomes):
                rows,stats=B.history(datetime(2026,12,1,tzinfo=timezone.utc))
            self.assertEqual(stats['completed'],2);self.assertEqual(stats['active_completed'],1)
            self.assertEqual(stats['hit_rate'],1);self.assertEqual(stats['total_gross_yield_score_bp'],4)
            self.assertIsNone(rows[-1]['score_bp']);self.assertNotIn('PRIVATE_LOCAL_PATH',json.dumps(rows))
            self.assertNotIn('features',rows[0])

    def test_observed_state_agrees_with_direction(self):
        self.assertTrue(B.state_text('us_eq',1).startswith('Fell'))
        self.assertTrue(B.state_text('usd',-1).startswith('Fell'))
        self.assertEqual(B.state_text('tips_30',0),'No eligible auction next week')
