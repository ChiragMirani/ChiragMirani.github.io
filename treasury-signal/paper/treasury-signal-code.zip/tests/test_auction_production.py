import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
import model as M
import production_signal as P
import auction_inputs as A


class AuctionTests(unittest.TestCase):
    def row(self,ann='2026-11-12',auction='2026-11-19',term='30-Year 6-Month'):
        return dict(cusip='912810ZZ9',security_type='Bond',original_security_term=term,
                    inflation_index_security='Yes',announcemt_date=ann,auction_date=auction)

    def test_strict_announcement_and_horizon_with_reopening(self):
        idx=pd.to_datetime(['2026-11-06','2026-11-13','2026-11-20'])
        self.assertEqual(A.tips_flag(idx,[self.row()]).tolist(),[0,1,0])
        self.assertEqual(A.tips_flag(idx,[self.row(ann='2026-11-13')]).tolist(),[0,0,0])
        self.assertEqual(A.tips_flag(idx,[self.row(auction='2026-11-20')]).tolist(),[0,1,0])
        self.assertEqual(A.tips_flag(idx,[self.row(term='20-Year')]).tolist(),[0,0,0])

    def test_unknown_calendar_is_not_zero(self):
        for bad in ([],{},[{}]):
            with self.assertRaises((ValueError,KeyError)):A.normalize_announced(bad)
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder:
            with self.assertRaises(FileNotFoundError):A.read_calendar(folder)

    def test_calendar_conflicts_are_rejected(self):
        with self.assertRaisesRegex(ValueError,'Conflicting'):
            A.merge_calendar([self.row()],[self.row(ann='2026-11-11')])

    def test_feed_discards_every_auction_result_field(self):
        raw={'cusip':'912810ZZ9','securityType':'Bond','originalSecurityTerm':'30-Year',
             'inflationProtected':'Yes','announcementDate':'2026-11-12T00:00:00',
             'competitiveAuctionCloseDate':'2026-11-19T00:00:00','highYield':99,'bidToCoverRatio':99}
        self.assertEqual(set(A.normalize_announced([raw])[0]),set(A.FIELDS))

    @unittest.skipUnless((M.DATA/'DGS10.csv').exists(),'Requires archived research inputs')
    def test_selected_14_inputs_reproduce_trial_and_production_fit(self):
        d=M.load();rows=json.loads((M.ROOT/'auction_study/auction_calendar_records.json').read_text())
        a,f=A.selected_inputs(d,rows); result=M.two_key(a,f,d.dy_next_bp,refit_weeks=13)
        reference=pd.read_csv(M.ROOT/'auction_study/quarterly/all_weekly_positions.csv',index_col=0,parse_dates=True)
        mask=(d.index>=M.CLF_START)&d.dy_next_bp.notna()
        np.testing.assert_array_equal(result['two_key'][mask],reference.loc[mask,'tips_30_+1'])
        t=d.index[-1];spec=json.loads(P.SPEC_PATH.read_text())
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as folder,patch.object(P,'MODELS',Path(folder)):
            probability,artifact=P.fitted_model(f,d.dy_next_bp,t,spec,M.DATA)
            self.assertEqual(len(artifact['columns']),14)
            self.assertAlmostEqual(probability,result['prob'].loc[t],places=12)
        t=pd.Timestamp('2020-01-03');short=d.loc[:t].copy();short.loc[t,'dy_next_bp']=np.nan
        aa,ff=A.selected_inputs(short,rows); p=M.two_key(aa,ff,short.dy_next_bp,refit_weeks=13)['prob']
        self.assertAlmostEqual(p.loc[t],result['prob'].loc[t],places=12)
