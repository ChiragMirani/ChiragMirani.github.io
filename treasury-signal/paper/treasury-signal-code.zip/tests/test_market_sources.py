"""Original-publisher fallbacks must not change history or accept the wrong series."""
import io
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import market_sources as S


class PublisherTests(unittest.TestCase):
    def setUp(self):
        self.dates = pd.bdate_range('2026-10-01', '2026-11-06')
        self.direct = pd.Series([4+i/100 for i in range(len(self.dates))], index=self.dates)
        self.fred = self.direct.iloc[:-1].copy()

    def test_only_missing_recent_dates_are_added(self):
        changed = self.direct.copy(); changed.iloc[0] = 99
        changed.loc[pd.Timestamp('2026-11-09')] = 20
        additions, proof = S.checked_extension(self.fred, changed, '2026-11-06')
        self.assertEqual(list(additions.index), [pd.Timestamp('2026-11-06')])
        self.assertEqual(proof['observations'], 20)
        self.assertEqual(self.fred.iloc[0], 4)

    def test_recent_conflict_wrong_series_and_short_overlap_rejected(self):
        changed = self.direct.copy(); changed.iloc[-2] += .01
        for direct in [changed, self.direct*10, self.direct.tail(10)]:
            with self.assertRaises(ValueError): S.checked_extension(self.fred, direct, '2026-11-06')

    def test_stale_missing_and_duplicate_dates_rejected(self):
        for fred, direct in [(self.fred.iloc[:-10], self.direct), (self.fred,self.direct.iloc[:-1]),
                             (self.fred,pd.concat([self.direct,self.direct.tail(1)]))]:
            with self.assertRaises(ValueError): S.checked_extension(fred, direct, '2026-11-06')
        with self.assertRaises(ValueError): S.parse(b'DATE,CLOSE\n11/06/2026,25\n11/06/2026,26\n','DATE','CLOSE')

    def test_snapshot_preserves_values_and_audits_only_missing_day(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            root = Path(directory)
            for code in ['DGS10','DGS2','VIXCLS']:
                frame = self.fred.copy(); frame.loc[self.dates[-1]] = float('nan')
                frame.to_frame(code).to_csv(root/(code+'.csv'), index_label='observation_date')
            def fetch(url):
                dates = self.dates.strftime('%m/%d/%Y')
                frame = pd.DataFrame({'DATE':dates,'CLOSE':self.direct.values}) if url==S.CBOE else pd.DataFrame({'Date':dates,'2 Yr':self.direct.values,'10 Yr':self.direct.values})
                return frame.to_csv(index=False).encode()
            report = S.supplement_snapshot(root, fetch, datetime(2026,11,7,21,tzinfo=timezone.utc))
            self.assertEqual(len(report['additions']),3)
            for code in ['DGS10','DGS2','VIXCLS']:
                result = pd.read_csv(root/(code+'.csv'),index_col=0,parse_dates=True).iloc[:,0]
                pd.testing.assert_series_equal(result.loc[self.fred.index], self.fred,check_names=False,check_freq=False)
                self.assertAlmostEqual(result.iloc[-1], self.direct.iloc[-1])
            again = S.supplement_snapshot(root,lambda _:self.fail('Must not redownload complete dates'),datetime(2026,11,7,21,tzinfo=timezone.utc))
            self.assertEqual(again['additions'],[])


if __name__=='__main__': unittest.main()
