Economic interpretation audit - November 7, 2026

The author requested a whole-paper audit after challenging the natural-gas sign
and suggesting that markets might already have priced in, or overreacted to,
energy news. The checks here were specified after seeing the 2026 ranking.
They are descriptive follow-ups, not new out-of-sample tests or a new model.

diagnostics.py reports all cells, including unchanged states, for:
1. Gas four-week direction versus the previous four-week Treasury yield move.
2. The same comparison using a previous one-week Treasury yield move.
3. Curve steepening with both yields falling, both rising, or a mixed move.
4. The number of weeks in each original-rule state during 2026.

Both prior-yield windows and both periods (2026 and 2023-2025) are reported;
no best window or rule is selected. Gas observations retain the model's
seven-day delay. Outcomes are the following Friday's yield change. Small cell
counts, overlapping predictor windows and repeated economic readings limit
inference. Co-movement does not measure expectations or prove overreaction.

Run python economic_review/diagnostics.py from the package folder. It reads
the archived study data or TREASURY_DATA_DIR and never changes production rules.
