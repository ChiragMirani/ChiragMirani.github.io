"""Descriptive checks requested after the sign discussion; no model selection."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import model as M


def aggregate(frame, groups):
    return frame.groupby(groups, dropna=False).agg(
        weeks=('dy_next_bp', 'size'), mean_next_yield_bp=('dy_next_bp', 'mean'),
        median_next_yield_bp=('dy_next_bp', 'median'),
        fraction_next_down=('dy_next_bp', lambda y: float((y < 0).mean())))


def main():
    d = M.load()
    a = M.answers_13(d)
    d = d.assign(gas_4w=d.natgas.diff(4), yield_4w_bp=d.y10.diff(4)*100,
                 yield_1w_bp=d.y10.diff()*100, y2_4w_bp=d.y2.diff(4)*100,
                 slope_4w_bp=(d.y10-d.y2).diff(4)*100)
    d = d[d.dy_next_bp.notna()].copy()
    periods = {'2026':d.index.year == 2026,
               '2023-2025':(d.index.year >= 2023)&(d.index.year <= 2025)}
    gas_rows, curve_rows = [], []
    for period, mask in periods.items():
        z = d.loc[mask].copy()
        z['gas_state'] = np.sign(z.gas_4w).map({1:'up', -1:'down', 0:'unchanged'})
        for horizon in ['4w', '1w']:
            z['prior_yield_state'] = np.sign(z[f'yield_{horizon}_bp']).map({1:'up', -1:'down', 0:'unchanged'})
            r = aggregate(z, ['gas_state','prior_yield_state']).reset_index()
            r.insert(0, 'period', period);r.insert(1, 'prior_yield_window', horizon)
            gas_rows.append(r)
        steep = z[z.slope_4w_bp > 1e-8].copy()
        steep['steepening_type'] = np.select(
            [(steep.yield_4w_bp < 0)&(steep.y2_4w_bp < 0),
             (steep.yield_4w_bp > 0)&(steep.y2_4w_bp > 0)],
            ['both_yields_falling','both_yields_rising'], default='mixed_or_one_unchanged')
        r = aggregate(steep, ['steepening_type']).reset_index()
        r.insert(0, 'period', period);curve_rows.append(r)
    gas = pd.concat(gas_rows, ignore_index=True)
    curve = pd.concat(curve_rows, ignore_index=True)
    gas.to_csv(HERE/'gas_prior_yield_states.csv', index=False)
    curve.to_csv(HERE/'curve_steepening_types.csv', index=False)
    main = pd.read_csv(ROOT/'results/two_key_weekly.csv', index_col=0, parse_dates=True)
    q = d.index[(d.index >= '2026-01-01') & (d.index < '2027-01-01')]
    readings = []
    for key in a:
        s = a.loc[q, key]
        readings.append({'key':key, 'weeks':len(s), 'add_weeks':int((s > 0).sum()),
                         'reduce_weeks':int((s < 0).sum()), 'neutral_weeks':int((s == 0).sum()),
                         'state_changes':int(s.diff().iloc[1:].ne(0).sum())})
    pd.DataFrame(readings).to_csv(HERE/'main_rule_2026_states.csv', index=False)
    decimal = a.index[(a.index >= '2016-11-04') & (a.index <= d.index[-1]) & (a.index.month == 12)]
    info = {'scope':'Post-discussion descriptive audit; windows and comparisons are not an independent test.',
            'main_rules':len(a.columns), 'december_later_weeks':len(decimal),
            'december_later_distinct_years':len(decimal.year.unique()),
            'unchanged_yield_weeks_later':int((main.loc[main.index >= '2016-11-04','dy_next_bp'] == 0).sum()),
            'gas_reversal_checks':gas.to_dict('records'), 'curve_checks':curve.to_dict('records')}
    (HERE/'summary.json').write_text(json.dumps(M.nan_to_none(info),indent=2,allow_nan=False),encoding='utf-8')
    print('Gas diagnostic: both 1-week and 4-week prior-yield windows retained.')
    print(curve.round(3).to_string(index=False))
    print('December weeks / separate years:',len(decimal),len(decimal.year.unique()))


if __name__ == '__main__':
    main()
