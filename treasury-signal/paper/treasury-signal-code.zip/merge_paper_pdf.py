"""Join the cover and body rendered by make_pdf.js; preserve their page numbers."""
from pathlib import Path
import sys
from pypdf import PdfReader, PdfWriter


def main():
    cover, body, output = map(Path, sys.argv[1:])
    writer = PdfWriter()
    for source in [cover, body]:
        writer.append(PdfReader(source))
    writer.add_metadata({'/Title':'A Simple Weekly Signal for the U.S. 10-Year Treasury Yield',
                         '/Author':'Chirag Mirani',
                         '/Subject':'Weekly US 10-year Treasury yield forecasting and duration timing; preprint and signal tool at https://chiragmirani.github.io/treasury-signal/',
                         '/Keywords':'U.S. Treasury yield forecasting, duration management, bond market timing, checklist, logistic regression, Treasury auctions',
                         '/Language':'en-US'})
    writer.write(output)


if __name__=='__main__':
    main()
