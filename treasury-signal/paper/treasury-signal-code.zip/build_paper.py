"""
Build paper.html from saved research outputs and the separately dated paper preview.
Historical headline numbers come from result files; the practical example is explicitly hypothetical.
Run make_pdf.js to render the title page and the body with its running header.

Run:  python build_paper.py
"""
# base64 lets us put the chart pictures inside the HTML file, so the page is one self-contained file.
import base64
# json reads the summary numbers that model.py saved.
import json
from datetime import datetime
from html import escape
# Path builds file paths that work on any computer.
from pathlib import Path
from zoneinfo import ZoneInfo

# pandas reads the result tables.
import pandas as pd

# The folder this file lives in.
ROOT = Path(__file__).resolve().parent
# The folder with the results.
RES = ROOT / "results"
# Every headline number.
R = json.loads((RES / "summary.json").read_text())
# Every question tested on its own.
hunt = pd.read_csv(RES / "feature_hunt.csv")
# The step-by-step choice of two extra questions.
steps = pd.read_csv(RES / "selection_steps.csv")
# The hindsight comparison.
hind = pd.read_csv(RES / "hindsight_check.csv")
# The weekly record.
tw = pd.read_csv(RES / "two_key_weekly.csv", index_col=0, parse_dates=True)
# Yearly totals (2016 split).
by_year = pd.read_csv(RES / "two_key_by_year.csv", index_col=0)
# The model's weights at each refit.
coefs = pd.read_csv(RES / "classifier_coefficients.csv")
# The last year by quarter.
lyq = pd.read_csv(RES / "last_year_by_quarter.csv", index_col=0)


def img(name: str) -> str:
    """Turn a chart file into an <img> tag with the picture inside it."""
    # Read the picture and encode it as text.
    b = base64.b64encode((ROOT / "charts" / name).read_bytes()).decode()
    # Hand back the tag.
    return f'<img src="data:image/png;base64,{b}">'


def pct(x) -> str:
    """0.5238 -> '52.4%'."""
    # Multiply by 100, one decimal.
    return f"{100 * x:.1f}%"


def rng(e: dict) -> str:
    """The 95% range of a hit ratio as text, e.g. '46.9% to 57.8%'."""
    # Low and high ends.
    lo, hi = e["hit_ratio_95"]
    # Format them.
    return f"{100 * lo:.0f}% to {100 * hi:.0f}%"


# Shortcuts to the annual reference model (13 questions) in each period.
M_d, M_t, M_l = R["two_key_design"], R["two_key_test"], R["two_key_last_year"]
# Each key on its own.
C_d, C_t, L_d, L_t = R["checklist_design"], R["checklist_test"], R["classifier_design"], R["classifier_test"]
# The 15-question search result.
S_d, S_t = R["two_key15_design"], R["two_key15_test"]
# Placebo summaries.
plc, plc_s = R["placebo"]["conditional"], R["placebo"]["search_procedure_15q"]
# Paired comparisons.
pc, pk = R["paired_two_key_minus_classifier_test"], R["paired_two_key_minus_checklist_test"]
# Turnover, last year, latest reading and the two searched questions.
turn, ly, latest, added = R["two_key_turnover_test"], R["last_12_months"], R["latest"], R["added_questions"]


def row(name: str, e1: dict, e2: dict) -> str:
    """One row of a results table: design period on the left, test period on the right."""
    # Cells for one period.
    def cells(e):
        # Active weeks, hit ratio, score per year, t-statistic, Sharpe-like ratio.
        return (f"<td>{e['active_weeks']}</td><td>{pct(e['hit_ratio'])}</td><td>{e['bp_per_year']:+.0f}</td>"
                f"<td>{e['t_stat']:+.2f}</td><td>{e['sharpe_like']:.2f}</td>")
    # The whole row.
    return f"<tr><td>{name}</td>{cells(e1)}{cells(e2)}</tr>"


# Table 3: main results.
main_rows = (row("Checklist alone", C_d, C_t) + row("Classifier alone", L_d, L_t)
             + row("<b>Two-key (annual reference model)</b>", M_d, M_t))

# Table 1: the 13 rules.
SPEC = [
    ("Nasdaq Composite 4-week return &gt; 0", "Sell", "Return exactly 0", "Friday close", "4-week log return"),
    ("Nasdaq Emerging Markets 4-week return &gt; 0", "Sell", "Return exactly 0", "Friday close", "4-week log return"),
    ("WTI oil 4-week return &gt; 0", "Sell", "Return exactly 0", "Observation + 7 days", "4-week log return"),
    ("Six-currency dollar index 4-week change &gt; 0", "Buy", "Change exactly 0", "Observation + 7 days", "4-week change"),
    ("VIX 4-week change &gt; 0", "Buy", "Change exactly 0", "Friday close", "4-week change"),
    ("Unemployment earliest archived monthly value &gt; mean of 60 earlier monthly values", "Buy (else sell)", "Not yet published", "Release date (archive)", "Gap"),
    ("Core PCE inflation, 12-month (within vintage) &lt; 2%", "Buy (else sell)", "Not yet published", "Release date (archive)", "Inflation minus 2"),
    ("10-year yield minus core PCE inflation &lt; 0", "Sell (else buy)", "Inflation unknown", "Friday close + archive", "Level"),
    ("2s10s spread 4-week change &gt; 0", "Buy", "Change exactly 0", "Friday close", "4-week change"),
    ("German 10-year yield, latest monthly change &gt; 0", "Sell", "Change exactly 0", "Release date (archive from 2013)", "Change"),
    ("Japanese 10-year yield, latest monthly change &gt; 0", "Sell", "Change exactly 0", "Release date (archive from 2013)", "Change"),
    ("UK 10-year yield, latest monthly change &gt; 0", "Sell", "Change exactly 0", "Release date (archive from 2013)", "Change"),
    ("Signal date is in December", "Sell", "Any other month", "Calendar", "0/1, not standardized"),
]
# Build the specification rows.
spec_rows = "".join(f"<tr><td class='l'>{i + 1}</td><td class='l'>{a}</td><td class='l'>{b}</td><td class='l'>{c}</td><td class='l'>{t}</td><td class='l'>{x}</td></tr>"
                    for i, (a, b, c, t, x) in enumerate(SPEC))

# Table 2: each question alone (the 13, then the 14 candidates).
hunt_rows = "".join(f"<tr><td class='l'>{r.group}</td><td class='l'>{r.question}</td><td>{pct(r.in_sample_hit)}</td><td>{r.in_sample_bp_yr:+.0f}</td><td>{r.in_sample_t:+.2f}</td>"
                    f"<td>{pct(r.out_sample_hit)}</td><td>{r.out_sample_bp_yr:+.0f}</td><td>{r.out_sample_t:+.2f}</td></tr>" for r in hunt.itertuples())

# Table 5: the search steps.
step_rows = ""
# One row per candidate per step, best first.
for r in steps.sort_values(["step", "design_t"], ascending=[True, False]).itertuples():
    # Bold the winner of each step.
    w = r.added == added[int(r.step) - 1]["key"]
    # Wrap the winner in bold tags.
    b0, b1 = ("<b>", "</b>") if w else ("", "")
    # The row.
    step_rows += f"<tr><td>{int(r.step)}</td><td class='l'>{b0}{r.added}{b1}</td><td class='l'>{r.family}</td><td>{pct(r.design_hit)}</td><td>{b0}{r.design_t:+.2f}{b1}</td></tr>"

# Table 4: hindsight comparison.
hind_rows = "".join(f"<tr><td class='l'>{r.version}</td><td>{r.design_bp_per_year:+.0f}</td><td>{r.design_t:+.2f}</td><td>{r.test_bp_per_year:+.0f}</td><td>{r.test_t:+.2f}</td></tr>"
                    for r in hind.itertuples())

# Table 6: robustness on the test period.
ROB = [("Annual reference", M_t), ("Refit every 26 weeks", R["robust_refit_26w_test"]), ("Refit every 13 weeks", R["robust_refit_13w_test"]),
       ("Strict agreement (both keys must have a view)", R["robust_strict_agreement_test"]),
       ("One extra week of market-input delay", R["robust_market_prices_one_week_late_test"]),
       ("Always expect lower yields", R["benchmark_always_buy_test"]), ("Always expect higher yields", R["benchmark_always_sell_test"]),
       ("Bet last week's move repeats", R["benchmark_last_week_test"])]
# Build the rows.
rob_rows = "".join(f"<tr><td class='l'>{n}</td><td>{e['active_weeks']}</td><td>{pct(e['hit_ratio'])}</td><td>{e['bp_per_year']:+.0f}</td><td>{e['t_stat']:+.2f}</td><td>{e['t_stat_8_lags']:+.2f}</td></tr>" for n, e in ROB)

# Table 7: the last year by quarter (assigned by signal date).
q_rows = "".join(f"<tr><td class='l'>{i}</td><td>{r.yield_change_bp:+.0f}</td><td>{int(r.two_key_active_weeks)}</td><td>{r.checklist:+.0f}</td><td>{r.classifier:+.0f}</td><td>{r.two_key:+.0f}</td></tr>"
                 for i, r in lyq.iterrows())
# A total row.
q_rows += (f"<tr><td class='l'><b>52 weeks</b></td><td><b>{lyq.yield_change_bp.sum():+.0f}</b></td><td><b>{int(lyq.two_key_active_weeks.sum())}</b></td>"
           f"<td><b>{lyq.checklist.sum():+.0f}</b></td><td><b>{lyq.classifier.sum():+.0f}</b></td><td><b>{lyq.two_key.sum():+.0f}</b></td></tr>")

# Leave-one-out over the last year: the three questions whose removal helps most and hurts most.
loo = pd.Series(ly["leave_one_out_change_bp"]).sort_values()
# Text for the biggest helpers (removing them makes the year worse).
loo_help = ", ".join(f"{k} ({v:+.0f}bp)" for k, v in loo.head(3).items())
# Text for the biggest drags (removing them makes the year better).
loo_drag = ", ".join(f"{k} ({v:+.0f}bp)" for k, v in loo.tail(3)[::-1].items())

# The 2016 split, read from the yearly table.
y16a = by_year.loc["2016 (Jan-Oct, design)", "two_key_bp"]
# The test part of 2016.
y16b = by_year.loc["2016 (Nov-Dec, test)", "two_key_bp"]
# Full test-period calendar years (2017 to 2025).
full_years = by_year.loc[[str(y) for y in range(2017, 2026)], "two_key_bp"]

# Latest weights, smallest to largest.
lc = coefs.iloc[-1].drop("refit").astype(float).sort_values()
# Build the rows.
coef_rows = "".join(f"<tr><td class='l'>{k}</td><td>{v:+.3f}</td></tr>" for k, v in lc.items())

# Every displayed headline comes from the same regenerated result files.
hit_range, last_hit_range = rng(M_t), rng(M_l)
pshort, p15 = R["paired_two_key_minus_short_test"], R["paired_15_minus_13_test"]
positive_full_years = int((full_years > 0).sum())
drawdown = abs(R["two_key_max_drawdown_test_bp"])
selected_names = "; ".join(x["rule"] + " (" + x["direction"] + ")" for x in added)
both_active_t = float(hind.iloc[-1]["test_active_t"])
latest_position = {0: "none", 1: "lower yields", -1: "higher yields"}[latest["two_key_position"]]
cumulative_image, year_image = img("cumulative.png"), img("two_key_by_year.png")
# The two additional searches are reported in full, including unsuccessful candidates.
search_results = json.loads((ROOT / "improvement_study/comparison.json").read_text())
ridge_results = json.loads((ROOT / "improvement_study/ridge_comparison.json").read_text())
search_best = search_results[search_results["winner_family"]]
ridge_best = ridge_results[ridge_results["winner_family"]]
search_design, search_later = search_best["periods"]["design"], search_best["periods"]["later"]
ridge_design, ridge_later = ridge_best["periods"]["design"], ridge_best["periods"]["later"]
search_pair, ridge_pair = search_best["paired_later"], ridge_best["paired_later"]
quality = search_results["probability_quality"]
brier_model, brier_half = quality["brier_model"], quality["brier_constant_half"]
family_descriptions = {"main_13":"the thirteen-rule model", "no_foreign_10":"the ten-rule model without foreign yields",
                       "market_7":"the seven-rule market model", "breakeven_14":"the fourteen-input model including breakeven inflation",
                       "calendar_trend_15":"the fifteen-rule model including the jobs proxy and yield trend"}
window_descriptions = {0:"all available history",520:"ten years of history",260:"five years of history"}
size_descriptions = {"fixed":"fixed positions", "probability":"probability-scaled positions", "checklist":"checklist-scaled positions", "forecast":"forecast-scaled positions"}
sc, rc = search_best['config'], ridge_best['config']
search_winner_description = (f"{family_descriptions[sc['family']]} using {window_descriptions[int(sc['window'])]}, "
    f"C = {sc['c']:g}, a {int(sc['refit'])}-week refit, {size_descriptions[sc['size']]} and probability cutoffs of "
    f"{.5+sc['margin']:.1%} for lower yields or {.5-sc['margin']:.1%} for higher yields")
if sc['minimum_score']:
    search_winner_description += f", with a minimum absolute checklist score of {int(sc['minimum_score'])}"
ridge_winner_description = (f"{family_descriptions[rc['family']]} using {window_descriptions[int(rc['window'])]}, "
    f"alpha = {rc['alpha']:g}, a {int(rc['refit'])}-week refit and {size_descriptions[rc['size']]}; it "
    f"{'requires checklist non-conflict' if rc['agreement'] else 'uses the regression direction alone'} "
    f"and an absolute predicted move of at least {rc['minimum_move']:g} bp")
ridge_result_sentence = (f"Its score goes from {ridge_design['gross_bp_year']:+.1f} bp/year in the early sample "
                         f"to {ridge_later['gross_bp_year']:+.1f} later, with a later-period t-statistic of {ridge_later['gross_t']:.2f}.")
baseline_later = search_results['baseline']['periods']['later']['gross_bp_year']
beating_families = sum(search_results[k]['periods']['later']['gross_bp_year'] > baseline_later for k in family_descriptions if k in search_results)
classification_family_sentence = ("None of the five input-set winners from that round beats the annual reference model's later-period average."
    if beating_families == 0 else f"{beating_families} of the five input-set winners exceed the annual reference model's later-period average; these are retrospective comparisons.")
search_conclusion = ("Neither overall in-sample winner improves the later-period score. I therefore keep the thirteen-rule "
    "model as the reference and report the searches as unsuccessful attempts to improve it."
    if max(search_later['gross_bp_year'],ridge_later['gross_bp_year']) <= baseline_later else
    "At least one in-sample winner improves the later-period average, but that comparison remains retrospective. "
    "I retain the thirteen-rule model as the reference pending prospective evidence.")
step_winners_rows = ""
for step, selected in enumerate(added, 1):
    r = steps[(steps.step == step) & (steps.added == selected["key"])].iloc[0]
    step_winners_rows += (f"<tr><td>{step}</td><td class='l'>{selected['rule']}</td><td class='l'>{r.family}</td>"
                         f"<td>{pct(r.design_hit)}</td><td>{r.design_t:+.2f}</td></tr>")
search_rows = ""
for name, result in [("Annual 13-rule reference", search_results["baseline"]),
                     ("Classification search winner", search_best), ("Expected-move search winner", ridge_best)]:
    early, late = result["periods"]["design"], result["periods"]["later"]
    search_rows += (f"<tr><td class='l'>{name}</td><td>{early['net_sr']:.2f}</td><td>{late['active_weeks']}</td>"
                    f"<td>{late['hit_rate']:.1%}</td><td>{late['mean_absolute_position']:.2f}</td>"
                    f"<td>{late['gross_bp_year']:+.1f}</td><td>{late['gross_t']:.2f}</td><td>{late['net_bp_year']:+.1f}</td></tr>")
family_labels = {"main_13":"Main 13", "no_foreign_10":"No foreign yields (10)", "market_7":"Market inputs (7)",
                 "breakeven_14":"With breakeven (14)", "calendar_trend_15":"With calendar and trend (15)"}
all_search_rows = ""
for label, results in [("Classification", search_results), ("Ridge", ridge_results)]:
    for key, name in family_labels.items():
        if key not in results:
            all_search_rows += f"<tr><td class='l'>{label}: {name}</td><td colspan='5' class='l'>No setting passed the early-sample eligibility rules</td></tr>"
            continue
        early, late = results[key]["periods"]["design"], results[key]["periods"]["later"]
        all_search_rows += (f"<tr><td class='l'>{label}: {name}</td><td>{early['net_sr']:.2f}</td><td>{late['gross_bp_year']:+.1f}</td>"
                            f"<td>{late['net_bp_year']:+.1f}</td><td>{late['gross_t']:.2f}</td><td>{late['mean_absolute_position']:.2f}</td></tr>")
# A separate, explicitly in-sample watchlist does not alter the frozen model.
watch = json.loads((ROOT / 'watchlist_2027/summary.json').read_text())
watch_all = pd.read_csv(ROOT / 'watchlist_2027/all_27_rules.csv').set_index('key')
watch_main = watch['main_model_2026']
latest_counts = watch['latest_checklist_counts']
watch_rows = ''
watch_conditions = {
    'natgas': 'Four-week natural-gas change', 'curve': 'Four-week change in the 2s10s spread',
    'oil': 'Four-week WTI change', 'usd': 'Four-week dollar change',
    'de10': 'Latest published monthly German yield change',
}
for r in watch['top_five']:
    condition = watch_conditions.get(r['key'], r['condition'])
    if r['key'] in watch_conditions:
        condition += ' &gt; 0'
    else:
        condition = escape(condition)
    true_mean, false_mean = r['mean_next_yield_bp_condition_true'], r['mean_next_yield_bp_condition_false']
    true_text = f"{true_mean:+.2f} ({r['condition_true_weeks']})" if true_mean is not None else 'No observations'
    false_text = f"{false_mean:+.2f} ({r['condition_false_weeks']})" if false_mean is not None else 'No observations'
    watch_rows += (f"<tr><td class='l'>{int(r['watchlist_rank'])}. {condition}</td>"
                   f"<td>{true_text}</td><td>{false_text}</td><td>{r['timing_bp']:+.1f}</td>"
                   f"<td>{r['2023_timing_bp']:+.1f}</td><td>{r['2024_timing_bp']:+.1f}</td><td>{r['2025_timing_bp']:+.1f}</td></tr>")
watch_ng, watch_de = watch_all.loc['natgas'], watch_all.loc['de10']
watch_oil, watch_usd = watch_all.loc['oil'], watch_all.loc['usd']
comovement = {r['key']:r for r in watch['same_week_comovement']}
oil_corr = comovement['oil']['pearson_correlation_with_same_week_yield_change']
usd_corr = comovement['usd']['pearson_correlation_with_same_week_yield_change']
watch_min_without_best = min(r['timing_bp_without_largest_week'] for r in watch['top_five'])
econ = json.loads((ROOT / 'economic_review/summary.json').read_text())
gas_states = pd.DataFrame(econ['gas_reversal_checks'])
def gas_cell(period, horizon, prior):
    return gas_states[(gas_states.period == period) & (gas_states.prior_yield_window == horizon)
                      & (gas_states.gas_state == 'up') & (gas_states.prior_yield_state == prior)].iloc[0]
gas_up_after_up = gas_cell('2026', '4w', 'up')
gas_up_after_down = gas_cell('2026', '4w', 'down')
gas_old_after_up = gas_cell('2023-2025', '4w', 'up')
# The paper retains this actual check timestamp when reproduced; refreshing is explicit.
preview = json.loads((RES/'paper_signal_preview.json').read_text())
checked = datetime.fromisoformat(preview['checked_at_utc']).astimezone(ZoneInfo('America/New_York'))
checked_label = checked.strftime('%d %B %Y, %I:%M:%S %p %Z')
reference_label = pd.Timestamp(preview['requested_reference_friday']).strftime('%d %B %Y')
signal_preview_panel = f'<p><b>Latest signal check:</b> {escape(checked_label)} (New York).</p>'
if preview['status'] == 'unavailable':
    signal_preview_panel += f'<p><b>{reference_label} reference: SIGNAL UNAVAILABLE.</b> '
    issues = preview['requested_data_error'] or 'Required input data did not pass validation.'
    for short, label in [('y10','10-year Treasury'), ('y2','2-year Treasury'), ('vix','VIX')]:
        issues = issues.replace(short, label)
    parts = issues.split('; ')
    if all(part.endswith(' is missing or stale') for part in parts):
        names = [part.removesuffix(' is missing or stale') for part in parts]
        issues = 'Required Friday observations are missing for ' + ', '.join(names)
    signal_preview_panel += escape(issues) + '.</p>'
else:
    signal_preview_panel += f'<p><b>{reference_label} reference: RESEARCH PREVIEW ONLY.</b></p>'
reading = preview['latest_complete_research_reading']
if reading is not None:
    label = 'Separately dated historical illustration' if preview['status']=='unavailable' else 'Preview reading'
    reading_date = pd.Timestamp(reading['reference_friday']).strftime('%d %B %Y')
    end_date = pd.Timestamp(reading['target_end']).strftime('%d %B %Y')
    signal_preview_panel += (f'<p><b>{label}, {reading_date}: {escape(reading["view"])}.</b> '
        f'Checklist {reading["checklist_score"]:+d} ({reading["votes_add"]} add, {reading["votes_reduce"]} reduce, '
        f'{reading["votes_neutral"]} neutral); probability of lower yields '
        f'{reading["prob_yield_down_uncalibrated"]:.1%}, uncalibrated. Target end: {end_date}.</p>')
signal_preview_panel += ('<p>Calculated at the check time above; not an issued live forecast. '
    f'First eligible live reference: {pd.Timestamp(preview["live_start"]).strftime("%d %B %Y")}. '
    'An older reading is not a current instruction.</p>')
# Separate, explicitly dated research extensions; neither changes the live model.
refit_review = json.loads((ROOT/'improvement_study/refit_comparison.json').read_text())
refit_annual = refit_review['52']['periods']
refit_quarter = refit_review['13']['periods']
refit_pair = refit_review['13']['paired_later']
quarterly_brier = refit_review['13']['brier_later']
selected_preview_example = 'The selected model has no complete dated preview available.'
if reading is not None:
    selected_preview_example = (f"For a dated illustration, the selected fourteen-rule model's {reading_date} research reading has "
        f"{reading['votes_add']} votes to add duration, {reading['votes_reduce']} to reduce and {reading['votes_neutral']} neutral: "
        f"a checklist score of {reading['checklist_score']:+d}. Its uncalibrated probability of lower yields is "
        f"{reading['prob_yield_down_uncalibrated']:.1%}. The combined reading is: {escape(reading['view'].lower())}. "
        "The cover records when this illustration was calculated.")
auction = json.loads((ROOT/'auction_study/summary.json').read_text())
selected_model_rows = ''
for label, r in [('Quarterly refit (selected)', refit_quarter['later']),
                 ('Annual refit (reference)', refit_annual['later']),
                 ('Always higher yields', auction['always_reduce']['later'])]:
    selected_model_rows += (f"<tr><td>{label}</td><td>{r['active_weeks']}</td><td>{r['hit_rate']:.1%}</td>"
        f"<td>{r['gross_bp_year']:+.1f}</td><td>{r['net_bp_year']:+.1f}</td><td>{r['gross_t']:.2f}</td></tr>")
auction_winner = auction['selection']['winner']
auction_chosen = auction['combined'][auction_winner['candidate']][str(auction_winner['sign'])]
auction_later = auction_chosen['later']
auction_year = auction_chosen['2026']
auction_base_year = auction['baseline']['2026']
auction_pair = auction_later['paired']
auction_constant_pair = auction_later['paired_always_reduce']
assert auction['announcement_audit']['passed'] == auction['announcement_audit']['sampled']
auction_names = {'nominal_20': '20-year nominal', 'nominal_30': '30-year nominal',
                 'tips_30': '30-year TIPS', 'any_long': 'Any of the three'}
auction_event_rows = ''
auction_model_rows = ''
auction_standalone_rows = ''
for name, label in auction_names.items():
    early = auction['conditional'][name]['early']
    period = 'since_20_reintroduction' if name == 'nominal_20' else 'later'
    later = auction['conditional'][name][period]
    early_mean = 'n/a' if early['event_mean_yield_change_bp'] is None else f"{early['event_mean_yield_change_bp']:+.2f}"
    auction_event_rows += (f"<tr><td>{label}</td><td>{early['event_weeks']}</td><td>{early_mean}</td>"
        f"<td>{later['event_weeks']}</td><td>{later['event_mean_yield_change_bp']:+.2f}</td>"
        f"<td>{later['non_event_mean_yield_change_bp']:+.2f}</td></tr>")
    r = auction['standalone'][name]['-1'][period]
    early_score = 'n/a' if name == 'nominal_20' else f"{auction['standalone'][name]['-1']['early']['gross_bp_year']:+.1f}"
    auction_standalone_rows += (f"<tr><td>{label}</td><td>{early_score}</td><td>{r['gross_bp_year']:+.1f}</td>"
        f"<td>{r['net_bp_year']:+.1f}</td><td>{r['gross_t']:.2f}</td>"
        f"<td>{auction['standalone'][name]['1'][period]['gross_bp_year']:+.1f}</td></tr>")
    for sign in [-1, 1]:
        r = auction['combined'][name][str(sign)][period]
        vote = 'Reduce' if sign == -1 else 'Add'
        selected = '*' if name == auction_winner['candidate'] and sign == auction_winner['sign'] else ''
        window = '2020-26' if name == 'nominal_20' else '2016-26'
        auction_model_rows += (f"<tr><td>{label}{selected}</td><td>{vote}</td><td>{window}</td>"
            f"<td>{r['gross_bp_year']:+.1f}</td><td>{r['net_bp_year']:+.1f}</td>"
            f"<td>{r['paired']['gross_bp_year']:+.1f}</td><td>{r['paired']['gross_t']:.2f}</td></tr>")
for period, window in [('later', '2016-26'), ('since_20_reintroduction', '2020-26')]:
    r = auction['baseline'][period]
    auction_model_rows += (f"<tr><td>Annual reference</td><td>-</td><td>{window}</td><td>{r['gross_bp_year']:+.1f}</td>"
                          f"<td>{r['net_bp_year']:+.1f}</td><td>0.0</td><td>-</td></tr>")
auction_quarter = json.loads((ROOT/'auction_study/quarterly/summary.json').read_text())
aq_winner = auction_quarter['selection']['winner']
aq_chosen = auction_quarter['combined'][aq_winner['candidate']][str(aq_winner['sign'])]
aq_later = aq_chosen['later']
aq_pair = aq_later['paired']
auction_quarter_rows = ''
for name, label in auction_names.items():
    period = 'since_20_reintroduction' if name == 'nominal_20' else 'later'
    window = '2020-26' if name == 'nominal_20' else '2016-26'
    for sign in [-1, 1]:
        r = auction_quarter['combined'][name][str(sign)][period]
        vote = 'Reduce' if sign == -1 else 'Add'
        selected = '*' if name == aq_winner['candidate'] and sign == aq_winner['sign'] else ''
        auction_quarter_rows += (f"<tr><td>{label}{selected}</td><td>{vote}</td><td>{window}</td>"
            f"<td>{r['hit_rate']:.1%}</td><td>{r['gross_bp_year']:+.1f}</td><td>{r['net_bp_year']:+.1f}</td>"
            f"<td>{r['paired']['gross_bp_year']:+.1f}</td><td>{r['paired']['gross_t']:.2f}</td></tr>")
for period, window in [('later', '2016-26'), ('since_20_reintroduction', '2020-26')]:
    r = auction_quarter['baseline'][period]
    auction_quarter_rows += (f"<tr><td>Quarterly baseline</td><td>-</td><td>{window}</td><td>{r['hit_rate']:.1%}</td>"
        f"<td>{r['gross_bp_year']:+.1f}</td><td>{r['net_bp_year']:+.1f}</td><td>0.0</td><td>-</td></tr>")

# Final selected specification; original research tables above remain unchanged.
final = json.loads((RES/'selected_summary.json').read_text())
selected = final['periods']
selected_brier = final['brier_later']
public_abstract = ("A macro view tells a bond investor why to add or reduce duration. It still leaves a timing decision. "
    "I present a simple weekly signal for the U.S. 10-year Treasury yield to help review that decision. "
    "Fourteen market, economic and calendar readings form an equal-vote checklist. A logistic regression, refitted every 13 weeks, "
    "provides a second view; the combined signal takes a direction when the two do not conflict. "
    f"Across November 2016-October 2026, the selected model gets {selected['later']['hit_rate']:.1%} of {selected['later']['active_weeks']} active calls right "
    f"and scores {selected['later']['gross_bp_year']:+.1f} yield basis points per year, or {selected['later']['net_bp_year']:+.1f} after an illustrative charge. "
    "The refit frequency and 30-year TIPS auction addition were chosen after reviewing the historical results; the paper reports the searches "
    "and benchmarks alongside the selected model. A practical example shows how an investor with a bullish macro view can use the readings "
    "to add duration, wait or build gradually. The public tool supplies the dated checklist and an accumulating record of weekly outcomes. "
    "Scores measure yield direction, not portfolio returns; allocation size remains a portfolio decision.")
(RES/'publication_metadata.json').write_text(json.dumps({'title':'A Simple Weekly Signal for the U.S. 10-Year Treasury Yield',
    'author':'Chirag Mirani','date':'2026-11-07','version':'4','abstract':public_abstract,
    'keywords':['U.S. Treasury yield forecasting','duration management','bond market timing','checklist','logistic regression','Treasury auctions','real-time data'],
    'paper_url':'https://chiragmirani.github.io/treasury-signal/paper/',
    'tool_url':'https://chiragmirani.github.io/treasury-signal/'},indent=2),encoding='utf-8')
signal_preview_panel = ''
if reading is not None:
    signal_preview_panel = (f'<p><b>Latest complete reading: {reading_date} | {escape(reading["view"])}.</b></p>'
        f'<p>Checklist {reading["checklist_score"]:+d}: {reading["votes_add"]} add, {reading["votes_reduce"]} reduce, {reading["votes_neutral"]} neutral. '
        f'Regression: {reading["prob_yield_down_uncalibrated"]:.1%} for lower yields (uncalibrated).</p>'
        f'<p>Reference week ends {end_date}. Historical illustration calculated {escape(checked_label)} (New York); not issued on the reference date. '
        'See the tool for subsequent readings.</p>')
selected_model_rows = ''
for label,r in [('14 rules + quarterly refit (selected)',selected['later']),('13 rules + quarterly refit',refit_quarter['later']),
                ('13 rules + annual refit',refit_annual['later']),('Always expect higher yields',auction['always_reduce']['later'])]:
    selected_model_rows += (f"<tr><td>{label}</td><td>{r['active_weeks']}</td><td>{r['hit_rate']:.1%}</td>"
        f"<td>{r['gross_bp_year']:+.1f}</td><td>{r['net_bp_year']:+.1f}</td><td>{r['gross_t']:.2f}</td></tr>")
selected_year_rows=''.join(f"<tr><td>{r['year']}</td><td>{r['weeks']}</td><td>{r['active']}</td><td>{r['score_bp']:+.0f}</td></tr>" for r in final['by_year'])
selected_quarter_rows=''.join(f"<tr><td>{r['quarter']}</td><td>{r['weeks']}</td><td>{r['active']}</td><td>{r['yield_change_bp']:+.0f}</td><td>{r['score_bp']:+.0f}</td></tr>" for r in final['last_52_by_quarter'])
spec_rows += "<tr><td>14</td><td class='l'>30-year TIPS auction in next 7 days, announced before Friday</td><td class='l'>Buy</td><td class='l'>No eligible event</td><td class='l'>Announcement strictly before Friday</td><td class='l'>0/1, not standardized</td></tr>"
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
w=pd.read_csv(RES/'selected_weekly.csv',index_col=0,parse_dates=True).loc['2016-11-01':]
fig,ax=plt.subplots(figsize=(7,3.4));ax.plot(w.index,w.score_bp.cumsum(),color='#126d70',label='Selected 14-rule signal',lw=1.6)
ax.plot(w.index,w.dy_next_bp.cumsum(),color='#777777',label='Always expect higher yields',lw=1.2)
ax.axhline(0,color='#cccccc',lw=.6);ax.set_ylabel('Cumulative yield score (bp)');ax.legend(frameon=False,fontsize=8)
ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.15);fig.tight_layout()
fig.savefig(ROOT/'charts/selected_cumulative.png',dpi=170);plt.close(fig)
selected_chart=img('selected_cumulative.png')
html = (ROOT / "paper_template.html").read_text(encoding="utf-8").format_map(globals())
(ROOT / "paper.html").write_text(html, encoding="utf-8")
print("Saved paper.html")
