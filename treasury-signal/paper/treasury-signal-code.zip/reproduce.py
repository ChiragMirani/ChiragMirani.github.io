"""Rebuild research tables and paper HTML from a chosen input directory.
python reproduce.py --latest     uses the latest complete downloaded snapshot
python reproduce.py --data PATH  uses a particular archived input directory
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    choice = parser.add_mutually_exclusive_group()
    choice.add_argument('--latest', action='store_true')
    choice.add_argument('--data', type=Path)
    args = parser.parse_args()
    data = args.data or root / 'data'
    if args.latest:
        pointer = json.loads((root / 'data/latest_snapshot.json').read_text())
        data = root / 'data' / pointer['snapshot']
    data = data.resolve()
    if not (data / 'DGS10.csv').exists():
        parser.error('No input data found. Download first or supply --data PATH.')
    env = dict(os.environ, TREASURY_DATA_DIR=str(data), OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    print('Research inputs:', data, flush=True)
    print('New downloads may differ from the archived study. This does not issue live forecasts.', flush=True)
    for script in ['model.py', 'hindsight_check.py', 'improvement_study/search.py',
                   'improvement_study/expected_move_search.py', 'watchlist_2027/analyze.py',
                   'economic_review/diagnostics.py', 'improvement_study/compare_refits.py',
                   'auction_study/analyze.py']:
        subprocess.run([sys.executable, str(root / script)], cwd=root, env=env, check=True)
    subprocess.run([sys.executable, str(root/'auction_study/analyze.py'), '--refit-weeks', '13'], cwd=root, env=env, check=True)
    subprocess.run([sys.executable, str(root/'selected_model_results.py')], cwd=root, env=env, check=True)
    subprocess.run([sys.executable, str(root/'build_paper.py')], cwd=root, env=env, check=True)


if __name__ == '__main__':
    main()
