"""Run the disclosed training-sample search in PROTOCOL.txt. No production files change."""
import hashlib
import itertools
import json
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
import model as M

COST = 0.25
_CONTEXT = None


def write_json(path, obj):
    path.write_text(json.dumps(M.nan_to_none(obj), indent=2, allow_nan=False), encoding='utf-8')


def fit_prob(f, dy, window, c, refit):
    p = pd.Series(np.nan, index=f.index)
    first = f.index.get_loc(f.index[f.index >= M.CLF_START][0])
    for i in range(first, len(f), refit):
        start = max(0, i-window) if window else 0
        train = f.index[start:i]
        train = train[dy.loc[train].notna()]
        clf = LogisticRegression(C=c, max_iter=2000).fit(f.loc[train].values, (dy.loc[train] < 0).astype(int))
        test = f.index[i:i+refit]
        p.loc[test] = clf.predict_proba(f.loc[test].values)[:,1]
    return p


def positions(score, p, n, minimum_score, margin, size):
    pos = np.sign(np.sign(score) + np.sign(p-0.5))
    pos = pos.where((score.abs() >= minimum_score) & ((p-0.5).abs() >= margin), 0).fillna(0)
    if size == 'probability':
        pos *= ((p-0.5).abs()/0.10).clip(upper=1).fillna(0)
    elif size == 'checklist':
        pos *= score.abs()/n
    return pos


def score_arrays(pos, dy):
    p, y = np.asarray(pos, float), np.asarray(dy, float)
    keep = np.isfinite(y)
    p, y = p[keep], y[keep]
    if not np.isfinite(p).all() or (np.abs(p) > 1+1e-12).any():
        raise ValueError('Invalid position')
    gross = -p*y
    units = np.abs(np.diff(np.r_[0., p]))
    units[-1] += abs(p[-1])
    return p, gross, gross-COST*units, units


def nw_t(x, lags=4):
    x = np.asarray(x, float)
    e = x-x.mean()
    meat = float(e@e) + sum(2*(1-k/(lags+1))*float(e[k:]@e[:-k]) for k in range(1,min(lags,len(x)-1)+1))
    return float(x.mean()/np.sqrt(meat/len(x)**2)) if meat > 0 else np.nan


def metrics(pos, dy):
    p,gross,net,units=score_arrays(pos,dy)
    n=len(p);active=np.abs(p)>1e-12;cum=np.cumsum(gross)
    return {'weeks':n, 'active_weeks':int(active.sum()), 'hit_rate':float((gross[active]>0).mean()) if active.any() else np.nan,
            'mean_absolute_position':float(np.abs(p).mean()), 'gross_bp_year':float(gross.mean()*52),
            'net_bp_year':float(net.mean()*52), 'gross_t':nw_t(gross), 'net_t':nw_t(net),
            'gross_sr':float(gross.mean()/gross.std(ddof=1)*np.sqrt(52)) if gross.std()>0 else np.nan,
            'net_sr':float(net.mean()/net.std(ddof=1)*np.sqrt(52)) if net.std()>0 else np.nan,
            'turnover_year':float(units.sum()/n*52),
            'max_drawdown_bp':float((cum-np.maximum.accumulate(np.r_[0.,cum])[1:]).min())}


def feature_sets(d):
    a,f=M.answers_13(d),M.features_13(d)
    orientation=(d.index+pd.Timedelta(days=7)<pd.Timestamp('2016-11-01'))
    oriented=M.orient(M.candidates(d),d.dy_next_bp,orientation)
    a14,f14=M.extend(a,f,oriented,['breakeven'])
    a15,f15=M.extend(a,f,oriented,['jobs_next','trend'])
    market=['us_eq','em_eq','oil','usd','vix','curve','dec']
    return {'main_13':(a,f), 'no_foreign_10':(a.drop(columns=['de10','jp10','uk10']),f.drop(columns=['de10','jp10','uk10'])),
            'market_7':(a[market],f[market]), 'breakeven_14':(a14,f14), 'calendar_trend_15':(a15,f15)}


def initialize(context):
    global _CONTEXT
    _CONTEXT=context
    threadpool_limits(1)


def search_one(task):
    family,window,c,refit=task
    blocks,dy,mask=_CONTEXT
    a,f=blocks[family]
    p=fit_prob(f,dy,window,c,refit)
    s=a.sum(axis=1)
    rows=[]
    for min_score,margin,size in itertools.product([0,1,3],[0.,.025,.05],['fixed','probability','checklist']):
        pos=positions(s,p,len(a.columns),min_score,margin,size)
        e=metrics(pos[mask],dy[mask])
        left=mask & (dy.index.year<=2010); right=mask & (dy.index.year>=2011)
        net_left=score_arrays(pos[left],dy[left])[2].sum()
        net_right=score_arrays(pos[right],dy[right])[2].sum()
        eligible=e['active_weeks']>=.25*e['weeks'] and e['mean_absolute_position']>=.10 and net_left>0 and net_right>0
        rows.append({'family':family,'window':window,'c':c,'refit':refit,'minimum_score':min_score,'margin':margin,'size':size,
                     'eligible':bool(eligible),'early_half_net_total':float(net_left),'late_half_net_total':float(net_right),**e})
    return rows


def predictions(config, blocks, dy):
    a,f=blocks[config['family']]
    p=fit_prob(f,dy,int(config['window']),float(config['c']),int(config['refit']))
    pos=positions(a.sum(axis=1),p,len(a.columns),int(config['minimum_score']),float(config['margin']),config['size'])
    return pos,p


def main():
    d=M.load(); dy=d.dy_next_bp
    design=(d.index>=M.CLF_START)&(d.index+pd.Timedelta(days=7)<pd.Timestamp('2016-11-01'))&dy.notna()
    test=(d.index>=M.HOLDOUT_START)&dy.notna()
    assert d.index[design][-1]==pd.Timestamp('2016-10-21')
    blocks=feature_sets(d)
    cut=d.index[design][-1]
    early_blocks={k:(a.loc[:cut],f.loc[:cut]) for k,(a,f) in blocks.items()}
    context=(early_blocks,dy.loc[:cut],design[:len(dy.loc[:cut])])
    tasks=list(itertools.product(blocks,[0,520,260],[.01,.1,1.],[52,13]))
    rows=[]
    with ProcessPoolExecutor(max_workers=4,initializer=initialize,initargs=(context,)) as pool:
        for i,part in enumerate(pool.map(search_one,tasks,chunksize=1),1):
            rows.extend(part)
            if i%10==0:print(f'Fit streams {i}/{len(tasks)}; trials {len(rows)}',flush=True)
    trials=pd.DataFrame(rows)
    trials['trial_id']=np.arange(len(trials))
    trials.to_csv(ROOT/'all_in_sample_trials.csv',index=False)
    eligible=trials[trials.eligible].sort_values('net_sr',ascending=False,kind='stable')
    if eligible.empty:raise RuntimeError('No candidate passed the fixed eligibility rules')
    winner=eligible.iloc[0].to_dict()
    chosen=[g.iloc[0].to_dict() for _,g in eligible.groupby('family',sort=False)]
    selection={'protocol_sha256':hashlib.sha256((ROOT/'PROTOCOL.txt').read_bytes()).hexdigest(),
               'trials':len(trials),'eligible':len(eligible),'last_design_signal':str(cut.date()),
               'last_design_outcome':str((cut+pd.Timedelta(days=7)).date()),'winner':winner,'family_winners':chosen}
    write_json(ROOT/'selection_before_later_evaluation.json',selection)
    print('Training winner frozen:',{k:winner[k] for k in ['family','window','c','refit','minimum_score','margin','size','net_sr']},flush=True)
    # Only now calculate later-period results for the frozen shortlist.
    baseline={'family':'main_13','window':0,'c':.1,'refit':52,'minimum_score':0,'margin':0.,'size':'fixed'}
    base_pos,base_p=predictions(baseline,blocks,dy)
    configs=[('baseline',baseline)]+[(str(c['family']),c) for c in chosen]
    output={};weekly=pd.DataFrame({'dy_next_bp':dy,'baseline':base_pos},index=d.index)
    base_score=score_arrays(base_pos[test],dy[test])[1]
    base_net=score_arrays(base_pos[test],dy[test])[2]
    for name,config in configs:
        pos,p=predictions(config,blocks,dy)
        weekly[name]=pos
        gross,net=score_arrays(pos[test],dy[test])[1:3]
        periods={'design':design,'later':test,'2016_2019':test&(d.index.year<=2019),
                 '2020_2022':test&(d.index.year>=2020)&(d.index.year<=2022),
                 '2023_2026':test&(d.index.year>=2023),'last_52':d.index.isin(d.index[test][-52:])}
        output[name]={'config':config,'periods':{k:metrics(pos[m],dy[m]) for k,m in periods.items()},
                      'paired_later':{'gross_bp_year':float((gross-base_score).mean()*52),'gross_t':nw_t(gross-base_score),
                                      'net_bp_year':float((net-base_net).mean()*52),'net_t':nw_t(net-base_net)}}
    output['always_higher_yields']={'periods':{'later':metrics(pd.Series(-1.,index=d.index)[test],dy[test])}}
    target=(dy<0).astype(float).where(dy.notna())
    prior=target.expanding().mean().shift(1)
    output['probability_quality']={'brier_model':float(((base_p[test]-target[test])**2).mean()),
                                   'brier_constant_half':float(((.5-target[test])**2).mean()),
                                   'brier_past_frequency':float(((prior[test]-target[test])**2).mean())}
    buckets=pd.DataFrame({'p':base_p[test],'actual_down':target[test],'confidence':(base_p[test]-.5).abs(),
                          'right':(-np.sign(base_p[test]-.5)*dy[test]>0).astype(float)},index=d.index[test])
    buckets.groupby(pd.cut(buckets.p,[0,.4,.45,.5,.55,.6,1]),observed=False).agg(weeks=('p','size'),mean_probability=('p','mean'),actual_down=('actual_down','mean')).to_csv(ROOT/'probability_bins.csv')
    output['winner_family']=winner['family']
    output['search_size']=len(trials)
    write_json(ROOT/'comparison.json',output)
    weekly.to_csv(ROOT/'shortlist_weekly.csv')
    # Verify the separate fractional-position scorer against known main-model results.
    actual=output['baseline']['periods']['later']
    baseline_reference=M.evaluate(base_pos,dy.where(test))
    assert round(actual['gross_bp_year'],1)==baseline_reference['bp_per_year']
    assert round(actual['gross_t'],2)==baseline_reference['t_stat']
    p,g,n,u=score_arrays([.5,.5],[2.,-2.])
    assert np.allclose(g,[-1.,1.]) and np.isclose(u.sum(),1.)
    assert np.isclose(nw_t(base_score),M.hac_t(pd.Series(base_score)))
    print('Validation passed. Later results:',flush=True)
    for name,value in output.items():
        if isinstance(value,dict) and 'periods' in value:
            e=value['periods']['later'];print(name,{k:round(e[k],3) for k in ['gross_bp_year','gross_t','net_sr','hit_rate','mean_absolute_position']},flush=True)


if __name__=='__main__':
    with threadpool_limits(1):
        main()
