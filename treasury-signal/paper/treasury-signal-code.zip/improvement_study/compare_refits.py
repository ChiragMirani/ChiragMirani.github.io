"""Explain the existing 13-week refit sensitivity, without selecting a new model."""
from pathlib import Path
import sys
import pandas as pd
from threadpoolctl import threadpool_limits
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import model as M
from improvement_study.search import fit_prob, positions, metrics, score_arrays, nw_t, write_json


def main():
    d = M.load(); y = d.dy_next_bp; a = M.answers_13(d); f = M.features_13(d)
    early = (d.index >= M.CLF_START) & (d.index+pd.Timedelta(days=7) < pd.Timestamp('2016-11-01')) & y.notna()
    later = (d.index >= M.HOLDOUT_START) & y.notna()
    periods = {'early': early, 'later': later, '2016_2019': later & (d.index.year <= 2019),
               '2020_2022': later & (d.index.year >= 2020) & (d.index.year <= 2022),
               '2023_2026': later & (d.index.year >= 2023), '2026': later & (d.index.year == 2026),
               'last_52': d.index.isin(d.index[later][-52:])}
    out = {'scope': 'Post-discussion comparison of existing annual and 13-week refit sensitivity; expanding history, not a 13-week training window.',
           'selection_note': 'On November 7, 2026 the quarterly variant was selected for prospective use after inspecting the later historical comparison. Annual results remain the research reference; this is not a pre-2016-only choice.'}
    weekly = pd.DataFrame({'dy_next_bp':y}, index=d.index)
    base = None
    for refit in [52, 13]:
        probability = fit_prob(f, y, 0, .1, refit)
        pos = positions(a.sum(axis=1), probability, 13, 0, 0., 'fixed')
        direct = M.two_key(a,f,y,refit_weeks=refit)
        assert (direct['two_key'][later] == pos[later]).all()
        weekly[f'position_{refit}'] = pos
        weekly[f'probability_{refit}'] = probability
        gross, net = score_arrays(pos[later], y[later])[1:3]
        if base is None:
            base = (gross, net)
        out[str(refit)] = {'periods': {k: {**metrics(pos[m], y[m]),
                                    'hit_rate_95': M.evaluate(pos[m],y[m])['hit_ratio_95'],
                                    'gross_t_8': M.evaluate(pos[m],y[m])['t_stat_8_lags'],
                                    'gross_total_bp': float(score_arrays(pos[m],y[m])[1].sum())} for k, m in periods.items()},
                           'brier_later': float(((probability[later]-(y[later]<0).astype(float))**2).mean()),
                           'paired_later': {'gross_bp_year': float((gross-base[0]).mean()*52), 'gross_t': nw_t(gross-base[0]),
                                            'net_bp_year': float((net-base[1]).mean()*52), 'net_t': nw_t(net-base[1])}}
    write_json(HERE/'refit_comparison.json', out)
    weekly.to_csv(HERE/'refit_weekly.csv',index_label='signal_date')
    print('Saved annual / quarterly comparison with explicit retrospective-selection disclosure.')


if __name__ == '__main__':
    with threadpool_limits(1):
        main()
