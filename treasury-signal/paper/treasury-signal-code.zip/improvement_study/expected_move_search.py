"""Second, fully disclosed search: predict weekly yield-change size with ridge regression."""
import hashlib
import itertools
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits
import search as S

M=S.M
ROOT=S.ROOT
CTX=None


def initialize(context):
    global CTX
    CTX=context
    threadpool_limits(1)


def forecast(f,dy,window,alpha,refit):
    prediction=pd.Series(np.nan,index=f.index)
    first=f.index.get_loc(f.index[f.index>=M.CLF_START][0])
    for i in range(first,len(f),refit):
        start=max(0,i-window) if window else 0
        train=f.index[start:i];train=train[dy.loc[train].notna()]
        model=Ridge(alpha=alpha).fit(f.loc[train].values,-dy.loc[train].values)
        test=f.index[i:i+refit];prediction.loc[test]=model.predict(f.loc[test].values)
    return prediction


def position(score,pred,agreement,minimum,size):
    pos=np.sign(pred)
    if agreement:
        pos=pos.where((np.sign(score)==pos)|score.eq(0),0)
    pos=pos.where(pred.abs()>=minimum,0).fillna(0)
    if size=='forecast':pos*=pred.abs().div(5).clip(upper=1).fillna(0)
    return pos


def search_one(task):
    family,window,alpha,refit=task
    blocks,dy,mask=CTX;a,f=blocks[family]
    pred=forecast(f,dy,window,alpha,refit);score=a.sum(axis=1);rows=[]
    for agreement,minimum,size in itertools.product([False,True],[0.,1.,2.],['fixed','forecast']):
        pos=position(score,pred,agreement,minimum,size);e=S.metrics(pos[mask],dy[mask])
        left=mask&(dy.index.year<=2010);right=mask&(dy.index.year>=2011)
        first=S.score_arrays(pos[left],dy[left])[2].sum();last=S.score_arrays(pos[right],dy[right])[2].sum()
        eligible=e['active_weeks']>=.25*e['weeks'] and e['mean_absolute_position']>=.1 and first>0 and last>0
        rows.append({'family':family,'window':window,'alpha':alpha,'refit':refit,'agreement':agreement,
                     'minimum_move':minimum,'size':size,'eligible':bool(eligible),
                     'early_half_net_total':float(first),'late_half_net_total':float(last),**e})
    return rows


def main():
    d=M.load();dy=d.dy_next_bp;blocks=S.feature_sets(d)
    design=(d.index>=M.CLF_START)&(d.index+pd.Timedelta(days=7)<pd.Timestamp('2016-11-01'))&dy.notna()
    later=(d.index>=M.HOLDOUT_START)&dy.notna();cut=d.index[design][-1]
    context=({k:(a.loc[:cut],f.loc[:cut]) for k,(a,f) in blocks.items()},dy.loc[:cut],design[:len(dy.loc[:cut])])
    tasks=list(itertools.product(blocks,[0,520,260],[1.,10.,100.,1000.],[52,13]));rows=[]
    with ProcessPoolExecutor(max_workers=4,initializer=initialize,initargs=(context,)) as pool:
        for i,part in enumerate(pool.map(search_one,tasks),1):
            rows.extend(part)
            if i%20==0:print(f'Ridge streams {i}/{len(tasks)}; trials {len(rows)}',flush=True)
    trials=pd.DataFrame(rows);trials['trial_id']=np.arange(len(trials));trials.to_csv(ROOT/'ridge_in_sample_trials.csv',index=False)
    eligible=trials[trials.eligible].sort_values('net_sr',ascending=False,kind='stable')
    if eligible.empty:raise RuntimeError('No ridge candidate passed eligibility')
    winner=eligible.iloc[0].to_dict();chosen=[g.iloc[0].to_dict() for _,g in eligible.groupby('family',sort=False)]
    S.write_json(ROOT/'ridge_selection_before_later_evaluation.json',{'protocol_sha256':hashlib.sha256((ROOT/'SECOND_PROTOCOL.txt').read_bytes()).hexdigest(),'winner':winner,'family_winners':chosen,'trials':len(trials),'eligible':len(eligible)})
    print('Ridge training winner frozen:',winner,flush=True)
    baseline=M.two_key(*blocks['main_13'],dy)['two_key'];base_g=S.score_arrays(baseline[later],dy[later])[1]
    base_n=S.score_arrays(baseline[later],dy[later])[2];out={};weekly=pd.DataFrame({'dy_next_bp':dy,'baseline':baseline})
    for c in chosen:
        a,f=blocks[c['family']];pred=forecast(f,dy,int(c['window']),float(c['alpha']),int(c['refit']))
        pos=position(a.sum(axis=1),pred,bool(c['agreement']),float(c['minimum_move']),c['size']);weekly[c['family']]=pos
        gross,net=S.score_arrays(pos[later],dy[later])[1:3]
        masks={'design':design,'later':later,'2016_2019':later&(d.index.year<=2019),
               '2020_2022':later&(d.index.year>=2020)&(d.index.year<=2022),'2023_2026':later&(d.index.year>=2023),
               'last_52':d.index.isin(d.index[later][-52:])}
        out[c['family']]={'config':c,'periods':{k:S.metrics(pos[m],dy[m]) for k,m in masks.items()},
                          'paired_later':{'gross_bp_year':float((gross-base_g).mean()*52),'gross_t':S.nw_t(gross-base_g),
                                          'net_bp_year':float((net-base_n).mean()*52),'net_t':S.nw_t(net-base_n)}}
    out['no_eligible_families']=[key for key in blocks if key not in out]
    out['winner_family']=winner['family'];out['search_size']=len(trials)
    S.write_json(ROOT/'ridge_comparison.json',out);weekly.to_csv(ROOT/'ridge_shortlist_weekly.csv')
    for k,v in out.items():
        if isinstance(v,dict):print(k,{n:round(v['periods']['later'][n],3) for n in ['gross_bp_year','gross_t','net_sr','hit_rate']},flush=True)


if __name__=='__main__':
    with threadpool_limits(1):main()
