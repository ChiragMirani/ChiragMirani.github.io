"""
How much do alternative input definitions change the result? This reruns the main 13-question model with two inputs swapped
to the convenient, widely used versions, one at a time, so you can see what each one does.

  1. The Fed's broad dollar index (redesigned in 2019 and filled back to 2006) instead of six raw exchange rates.
  2. The New York Fed's term premium (re-estimated with today's full history) instead of yield less trailing inflation.

Run:  python hindsight_check.py      (writes results/hindsight_check.csv)
"""
# json is not needed here; pandas and numpy do the work.
import numpy as np
# pandas holds the tables.
import pandas as pd

# Reuse every building block from the main model so nothing else changes.
import model as M

# Build the weekly table as known each Friday (the hybrid reconstruction with disclosed timing assumptions).
d = M.load()
# Next week's change in the 10-year yield.
dy = d["dy_next_bp"]
# The design and test periods.
P = M.periods(d)

# The Fed's broad dollar index from 2006, extended back with its older index (the convenient version).
usd_new, usd_old = M.fred("DTWEXBGS"), M.fred("DTWEXM")
# Keep only the old index's days before the new one starts.
usd_old = usd_old[usd_old.index < usd_new.index[0]]
# Scale and join the two, then take logs to match how the main model stores the dollar.
broad_usd = np.log(M.asof(pd.concat([usd_old * (usd_new.iloc[0] / usd_old.iloc[-1]), usd_new]).shift(7, freq="D"), d.index))

# The New York Fed's term premium, read from its spreadsheet.
acm = pd.read_excel(M.DATA / "acm.xls")
# Its dates look like "31-Oct-2026".
acm["DATE"] = pd.to_datetime(acm["DATE"], format="%d-%b-%Y")
# A seven-day post-month-end delay is an assumption for this sensitivity exercise, not a verified release calendar.
tp = M.asof(M.monthly_known(pd.Series(acm["ACMTP10"].values, index=acm["DATE"]), 7), d.index)


def run(label: str, use_broad_usd: bool, use_tp: bool) -> dict:
    """Rebuild the 13 answers and inputs with the chosen swaps, run the two-key rule, and score both periods."""
    # Copy the weekly table so the swaps don't leak into other runs.
    dd = d.copy()
    # Swap in the backfilled dollar index if asked.
    if use_broad_usd:
        # Replace the six-currency index.
        dd["usd"] = broad_usd
    # Build the answers and the model inputs from the (possibly swapped) table.
    a, f = M.answers_13(dd).astype(float), M.features_13(dd)
    # Swap the yield-minus-trailing-inflation question for a term-premium question if asked.
    if use_tp:
        # Treat a negative estimated term premium as a reason to reduce duration; this is a hypothesis, not proof of mispricing.
        a["real"] = np.where(tp < 0, -1, 1)
        # The model sees how high the term premium is, compared with normal.
        f["real"] = M.zscore(tp).clip(-4, 4).fillna(0)
    # Run the two-key rule.
    tk = M.two_key(a, f, dy)["two_key"]
    # Score the design and test periods on the calendar-week basis.
    e1, e2 = M.evaluate(tk, dy.where(P["design"])), M.evaluate(tk, dy.where(P["test"]))
    # One row for the table.
    return {"version": label, "design_bp_per_year": e1["bp_per_year"], "design_t": e1["t_stat"],
            "test_bp_per_year": e2["bp_per_year"], "test_t": e2["t_stat"], "test_hit": e2["hit_ratio"],
            "test_active_t": round(M.hac_t(M.weekly_score(tk, dy.where(P["test"])).loc[tk.ne(0)].dropna()), 4)}


# The four combinations, from main inputs to both convenient inputs.
rows = [run("Main inputs (hybrid reconstruction)", False, False),
        run("Swap in the backfilled dollar index", True, False),
        run("Swap in the hindsight term premium", False, True),
        run("Swap in both", True, True)]
# Save the table.
pd.DataFrame(rows).to_csv(M.OUT / "hindsight_check.csv", index=False)
# Show it.
print(pd.DataFrame(rows).to_string(index=False))
