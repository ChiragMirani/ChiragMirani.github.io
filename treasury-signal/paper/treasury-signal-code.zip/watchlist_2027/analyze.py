"""Describe 2026 duration-timing relationships; never modify the live model."""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
import model as M

NAMES = {
    'us_eq': 'US equities', 'em_eq': 'Emerging-market equities', 'oil': 'WTI oil',
    'usd': 'Dollar basket', 'vix': 'VIX', 'slack': 'Unemployment gap',
    'pce': 'Core inflation below 2%', 'real': 'Yield less trailing inflation',
    'curve': '2s10s curve', 'de10': 'German yield', 'jp10': 'Japanese yield',
    'uk10': 'UK yield', 'dec': 'December', 'oil_yoy': 'WTI year-on-year',
    'gasoline': 'Retail gasoline', 'natgas': 'Natural gas', 'ovx': 'Oil volatility',
    'breakeven': 'Breakeven inflation', 'fed_bs': 'Fed balance sheet',
    'trend': '300-day yield trend', 'washout': 'Yield washout',
    'week_close': 'Yield near weekly high', 'fomc_next': 'Fed decision next week',
    'jobs_next': 'First-Friday proxy', 'fomc_anxiety': 'Fed week and rising VIX',
    'event_anxiety': 'Event week and rising VIX', 'vix_inverted': 'Inverted VIX curve',
}
BASE_TRUE = dict.fromkeys(NAMES, 1)
BASE_TRUE.update(dict.fromkeys(['us_eq', 'em_eq', 'oil', 'real', 'de10', 'jp10', 'uk10', 'dec'], -1))
BINARY = {'dec', 'washout', 'week_close', 'fomc_next', 'jobs_next', 'fomc_anxiety', 'event_anxiety', 'vix_inverted'}


def metrics(pos, dy):
    """Actual signed exposures; remove only each period's average duration bias."""
    p, y = np.asarray(pos, float), np.asarray(dy, float)
    if not len(p) or not (np.isfinite(p).all() and np.isfinite(y).all()):
        raise ValueError('Empty or nonfinite observations')
    gross = -p*y
    bias = float(-p.mean()*y.sum())
    timing = -(p-p.mean())*y
    active = p != 0
    changes = int(np.count_nonzero(np.diff(p)))
    turnover = np.abs(np.diff(np.r_[0., p, 0.])).sum()
    largest = int(np.argmax(timing))
    # Recompute the mean-position comparator after dropping that observation.
    reduced_p, reduced_y = np.delete(p, largest), np.delete(y, largest)
    reduced = float((-(reduced_p-reduced_p.mean())*reduced_y).sum())
    assert np.isclose(gross.sum(), bias+timing.sum())
    assert np.isclose(timing.sum(), -len(p)*np.cov(p, y, ddof=0)[0, 1])
    return {'weeks': len(p), 'active_weeks': int(active.sum()),
            'add_weeks': int((p == 1).sum()), 'reduce_weeks': int((p == -1).sum()),
            'neutral_weeks': int((p == 0).sum()), 'state_changes': changes,
            'mean_next_yield_bp_when_add': float(y[p == 1].mean()) if (p == 1).any() else None,
            'mean_next_yield_bp_when_reduce': float(y[p == -1].mean()) if (p == -1).any() else None,
            'average_tilt': float(p.mean()), 'mean_absolute_tilt': float(np.abs(p).mean()),
            'gross_bp': float(gross.sum()), 'constant_bias_bp': bias,
            'timing_bp': float(timing.sum()), 'gross_bp_per_52_weeks': float(gross.mean()*52),
            'timing_bp_per_52_weeks': float(timing.mean()*52),
            'hit_rate': float((gross[active] > 0).mean()) if active.any() else None,
            'turnover_units': float(turnover), 'largest_positive_timing_week_bp': float(timing.max()),
            'timing_bp_without_largest_week': reduced}


def eligibility(m):
    reasons = []
    if m['active_weeks'] < 20:
        reasons.append('fewer than 20 active weeks')
    if sum(m[k] >= 8 for k in ['add_weeks', 'reduce_weeks', 'neutral_weeks']) < 2:
        reasons.append('fewer than two states with eight weeks each')
    if m['state_changes'] < 4:
        reasons.append('fewer than four state changes')
    return '; '.join(reasons)


def main():
    d = M.load()
    a = M.answers_13(d)
    details = {key: {'group': group, 'condition': condition} for key, group, condition in M.QUESTIONS_13}
    for key, (group, condition, answer, _) in M.candidates(d).items():
        a[key] = answer.fillna(0)
        details[key] = {'group': group, 'condition': condition}
    complete = d.dy_next_bp.notna()
    sample = complete & (d.index >= '2026-01-01') & (d.index < '2027-01-01')
    y = d.loc[sample, 'dy_next_bp']
    assert len(a.columns) == 27
    assert set(np.unique(a.values)) <= {-1, 0, 1}
    assert np.isclose(y.sum(), (d.loc[y.index[-1]+pd.Timedelta(days=7), 'y10']-d.loc[y.index[0], 'y10'])*100)
    # Independent identity checks protect against accidental gross-score ranking.
    assert abs(metrics(np.full(len(y), -1.), y)['timing_bp']) < 1e-10
    assert np.isclose(metrics([1, -1, 1, -1], [-2, 3, -4, 5])['timing_bp'], 14)
    trials, selected = [], []
    periods = {'2023': (d.index.year == 2023), '2024': (d.index.year == 2024),
               '2025': (d.index.year == 2025),
               '2023_2025': ((d.index >= '2023-01-01') & (d.index < '2026-01-01')),
               '2026_jan_jun': (sample & (d.index < '2026-07-01')),
               '2026_jul_oct': (sample & (d.index >= '2026-07-01'))}
    for key in a:
        pair = []
        for direction in [1, -1]:
            m = metrics(a.loc[sample, key]*direction, y)
            r = dict(key=key, name=NAMES[key], direction=direction, **details[key], **m)
            r['exclusion_reason'] = eligibility(m)
            r['eligible'] = not r['exclusion_reason']
            trials.append(r)
            pair.append(r)
        r = max(pair, key=lambda x: x['timing_bp']).copy()
        true = int(BASE_TRUE[key]*r['direction'])
        r['when_condition_true'] = 'Add duration' if true == 1 else 'Reduce duration'
        r['otherwise'] = 'No tilt' if key in BINARY else ('Reduce duration' if true == 1 else 'Add duration')
        r['otherwise'] += '; exact change of zero / unavailable = no tilt' if key not in BINARY and key not in ['pce', 'real', 'slack', 'trend'] else ''
        # Describe outcomes directly. A relative timing advantage is not a buy/sell instruction.
        answers = a.loc[sample, key]
        yes = answers == BASE_TRUE[key]
        no = answers == (0 if key in BINARY else -BASE_TRUE[key])
        r['condition_true_weeks'] = int(yes.sum())
        r['condition_false_weeks'] = int(no.sum())
        r['mean_next_yield_bp_condition_true'] = float(y[yes].mean()) if yes.any() else None
        r['mean_next_yield_bp_condition_false'] = float(y[no].mean()) if no.any() else None
        r['usage_status'] = 'Descriptive in-sample association only; no live duration instruction'
        for period, mask in periods.items():
            m = metrics(a.loc[mask & complete, key]*r['direction'], d.loc[mask & complete, 'dy_next_bp'])
            r.update({f'{period}_{k}': v for k, v in m.items()})
        r['positive_prior_years'] = sum(r[f'{yr}_timing_bp'] > 1e-9 for yr in [2023, 2024, 2025])
        selected.append(r)
    table = pd.DataFrame(selected).sort_values(['eligible', 'timing_bp', 'key'], ascending=[False, False, True])
    table['watchlist_rank'] = pd.Series(range(1, int(table.eligible.sum())+1), index=table.index[table.eligible])
    pd.DataFrame(trials).to_csv(HERE / 'all_54_direction_trials.csv', index=False)
    table.to_csv(HERE / 'all_27_rules.csv', index=False)
    top = table[table.eligible].head(5).copy()
    top.to_csv(HERE / 'top_five.csv', index=False)
    weekly = []
    history = d.index[complete & (d.index >= '2023-01-01')]
    for row in table.to_dict('records'):
        key = row['key']
        for date in history:
            p, move = float(a.loc[date, key]*row['direction']), float(d.loc[date, 'dy_next_bp'])
            weekly.append({'signal_date': str(date.date()), 'outcome_date': str((date+pd.Timedelta(days=7)).date()),
                           'key': key, 'selected_direction': row['direction'], 'duration_view': p,
                           'signed_yield_score_bp': -p*move})
    pd.DataFrame(weekly).to_csv(HERE / 'selected_rule_weekly_scores.csv', index=False)

    # Contemporaneous market changes are explicitly ex post, never predictor inputs.
    raw = pd.DataFrame(index=d.index)
    for key, code in [('us_eq', 'NASDAQCOM'), ('em_eq', 'NASDAQNQEM'), ('oil', 'DCOILWTICO'), ('vix', 'VIXCLS')]:
        raw[key] = M.asof(M.fred(code), d.index)
    fx = [np.log(M.asof(1/M.fred(code) if inverse else M.fred(code), d.index)) for code, inverse in M.FX]
    raw['usd'] = pd.concat(fx, axis=1).mean(axis=1, skipna=False)
    covary = []
    for key in raw:
        level = np.log(raw[key]) if key in ['us_eq', 'em_eq'] else raw[key]
        change = level.shift(-1)-level
        pair = pd.concat([change.loc[sample], y], axis=1).dropna()
        covary.append({'key': key, 'name': NAMES[key], 'weeks': len(pair),
                       'pearson_correlation_with_same_week_yield_change': float(pair.iloc[:,0].corr(pair.iloc[:,1])),
                       'spearman_correlation_with_same_week_yield_change': float(pair.iloc[:,0].corr(pair.iloc[:,1], method='spearman'))})
    comovement = pd.DataFrame(covary)
    comovement['absolute_correlation'] = comovement.pearson_correlation_with_same_week_yield_change.abs()
    comovement.sort_values('absolute_correlation', ascending=False).to_csv(HERE / 'same_week_comovement.csv', index=False)

    baseline = pd.read_csv(ROOT / 'results/two_key_weekly.csv', index_col=0, parse_dates=True).loc[y.index]
    assert np.allclose(baseline.dy_next_bp, y)
    basem = metrics(baseline.two_key_position, y)
    assert np.isclose(basem['gross_bp'], baseline.two_key_bp.sum())
    summary = {'label': '2026 in-sample relationships to monitor in 2027',
               'usage_status': 'Descriptive only: selected position labels are scoring conventions, not recommendations',
               'research_date': '2026-11-07', 'signal_start': str(y.index[0].date()),
               'signal_end': str(y.index[-1].date()), 'outcome_start': str((y.index[0]+pd.Timedelta(days=7)).date()),
               'outcome_end': str((y.index[-1]+pd.Timedelta(days=7)).date()),
               'weeks': len(y), 'yield_change_bp': float(y.sum()),
               'rules_examined': len(a.columns), 'direction_trials': len(trials),
               'eligible_rules': int(table.eligible.sum()), 'top_five': top.to_dict('records'),
               'main_model_2026': basem, 'same_week_comovement': comovement.to_dict('records'),
               'latest_checklist_counts': {'as_of': str(d.index[-1].date()),
                    'add': int((a.loc[d.index[-1], [q[0] for q in M.QUESTIONS_13]] == 1).sum()),
                    'reduce': int((a.loc[d.index[-1], [q[0] for q in M.QUESTIONS_13]] == -1).sum()),
                    'neutral': int((a.loc[d.index[-1], [q[0] for q in M.QUESTIONS_13]] == 0).sum())},
               'protocol_sha256': hashlib.sha256((HERE / 'PROTOCOL.txt').read_bytes()).hexdigest(),
               'model_source_sha256': hashlib.sha256((ROOT / 'model.py').read_bytes()).hexdigest(),
               'paper_weekly_results_sha256': hashlib.sha256((ROOT / 'results/two_key_weekly.csv').read_bytes()).hexdigest()}
    (HERE / 'summary.json').write_text(json.dumps(M.nan_to_none(summary), indent=2, allow_nan=False), encoding='utf-8')
    lines = ['2026 RELATIONSHIPS TO WATCH IN 2027', '',
             f"Sample: {len(y)} completed weekly signals, {summary['signal_start']} to {summary['signal_end']}; outcomes through {summary['outcome_end']}.",
             'These are in-sample rankings from the frozen paper data, not predictions of which rules will work in 2027.',
             'The full 2026 year is not yet available. Both directions of all 27 existing rules were examined.',
             'The five shown passed the disclosed activity/state filters; thresholds were not retuned.', '',
             'Interpretation: these are descriptive associations, not instructions to add or reduce duration.',
             'The retained position labels are historical scoring conventions. The frozen model does not change.',
             'The timing score subtracts the hindsight benefit of each rule\'s average directional tilt.',
             'Scores below are gross yield-change points over this sample, not portfolio returns or tradeable profits.', '',
             'Rank | Indicator | Gross bp | Timing bp | Positive timing years, 2023-25 | State changes']
    for r in top.to_dict('records'):
        lines += [f"{int(r['watchlist_rank'])} | {r['name']} | {r['gross_bp']:+.1f} | {r['timing_bp']:+.1f} | {r['positive_prior_years']}/3 | {r['state_changes']}",
                  f"    Condition: {r['condition']}.",
                  f"    Mean next-week yield change when true: {r['mean_next_yield_bp_condition_true']:+.2f} bp ({r['condition_true_weeks']} weeks); opposite state: {r['mean_next_yield_bp_condition_false']:+.2f} bp ({r['condition_false_weeks']} weeks).",
                  f"    Timing points by year: 2023 {r['2023_timing_bp']:+.1f}, 2024 {r['2024_timing_bp']:+.1f}, 2025 {r['2025_timing_bp']:+.1f}.",
                  f"    2026 Jan-Jun {r['2026_jan_jun_timing_bp']:+.1f}; Jul-Oct {r['2026_jul_oct_timing_bp']:+.1f}. After dropping the largest helpful timing week: {r['timing_bp_without_largest_week']:+.1f}."]
    lines += ['', 'Natural gas, oil and the dollar use observations delayed seven days.',
              'The curve is the four-week change in the 10-year minus 2-year yield.',
              'The German reading is the latest archived MONTHLY change, repeated until a new release.',
              'It is not a contemporaneous weekly Bund move. Four state changes are a limited sample.',
              'Oil and German-yield directions in this watchlist reverse the main checklist directions.',
              'Natural gas and oil have selected signs opposite to a simple inflation-continuation hypothesis.',
              'An already-priced or overshot response could explain a reversal, but these data do not establish that mechanism.',
              'Lower conditional yield changes can still be positive. A positive timing score does not establish an add-duration case.',
              'Natural gas is absent from the frozen 13-rule model. Its selected direction lost timing points in 2023 and 2024.',
              'The main model continues to use its existing definitions; this list is a separate research panel.',
              'Same-week market correlations are in a separate file and never enter the forecast.', '',
              f"In 2026 the main model scored {basem['gross_bp']:+.1f} bp; reducing duration every week scored {y.sum():+.1f} bp.",
              f"The model's constant-bias component was {basem['constant_bias_bp']:+.1f} bp, leaving {basem['timing_bp']:+.1f} bp of descriptive timing contribution.",
              'Core inflation stayed on one side of its cutoff, so its timing score is zero.',
              'Published weekly forecasts and actual portfolio execution are needed to assess live usefulness.',
              'All input-vintage, availability and selection limitations in the paper still apply.']
    (HERE / 'FINDINGS.txt').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print('Weeks:', len(y), 'Yield change:', round(y.sum(), 2), 'Main model:', round(basem['gross_bp'], 2))
    print(table[['key','direction','eligible','gross_bp','timing_bp','active_weeks','state_changes',
                 'positive_prior_years','2023_2025_timing_bp_per_52_weeks','2026_jan_jun_timing_bp','2026_jul_oct_timing_bp']].round(2).to_string(index=False))
    print(comovement.round(3).to_string(index=False))


if __name__ == '__main__':
    main()
